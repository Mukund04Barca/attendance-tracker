# Attendance Tracker - Android Apps

Two complete Android apps — React Native and Flutter.
Both connect to your existing Django backend via JWT API.

---

## FLUTTER APP (Recommended — best native feel)

### Prerequisites
1. Install Flutter SDK: https://docs.flutter.dev/get-started/install
2. Install Android Studio + Android SDK
3. Enable Developer Mode on your Android phone

### Build Steps

```bash
cd flutter/attendance_tracker
flutter pub get
flutter build apk --release
```

APK location: `build/outputs/flutter-apk/app-release.apk`

### Install on phone

```bash
flutter install
# OR copy the APK to phone and install manually
```

### Run in debug mode (faster for testing)

```bash
flutter run
```

---

## REACT NATIVE APP

### Prerequisites
1. Install Node.js: https://nodejs.org
2. Install Android Studio + Android SDK
3. Set ANDROID_HOME environment variable

### Setup

```bash
cd react-native/AttendanceTracker
npm install
```

### Run on Android

```bash
npx react-native run-android
```

### Build release APK

```bash
cd android
./gradlew assembleRelease
# APK: android/app/build/outputs/apk/release/app-release.apk
```

---

## Connecting to your server

- Start your Django server: `py manage.py runserver 0.0.0.0:8000`
- Find your PC IP: run `ipconfig` → look for IPv4 Address
- In the app login screen, enter: `http://YOUR_IP:8000`
- Login with your Django username and password

---

## Features
- ✅ Check-in / Check-out with live HH:MM timer
- ✅ Remaining time + suggested checkout
- ✅ Manual time edit with validation
- ✅ Monthly history with HH:MM durations
- ✅ Leave balances (all 6 Cognizant types) — editable
- ✅ Earnings calculator (weekday/saturday/LOP)
- ✅ Earnings configuration (rates, saturday mode)
- ✅ JWT auth with auto token refresh
- ✅ Pull-to-refresh everywhere
- ✅ Dark theme matching web app
