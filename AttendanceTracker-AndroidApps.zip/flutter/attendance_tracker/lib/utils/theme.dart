import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const bg       = Color(0xFF020617);
  static const surface  = Color(0xFF0F172A);
  static const card     = Color(0xFF0F172A);
  static const border   = Color(0x14FFFFFF);
  static const borderHi = Color(0x40006EFF);
  static const cyan     = Color(0xFF06B6D4);
  static const emerald  = Color(0xFF10B981);
  static const amber    = Color(0xFFF59E0B);
  static const danger   = Color(0xFFF43F5E);
  static const purple   = Color(0xFFA78BFA);
  static const text     = Color(0xFFF1F5F9);
  static const muted    = Color(0xFF94A3B8);
  static const dim      = Color(0xFF475569);
}

ThemeData buildTheme() {
  return ThemeData(
    brightness: Brightness.dark,
    scaffoldBackgroundColor: AppColors.bg,
    colorScheme: const ColorScheme.dark(
      primary:   AppColors.cyan,
      secondary: AppColors.emerald,
      surface:   AppColors.surface,
      error:     AppColors.danger,
    ),
    textTheme: GoogleFonts.interTextTheme(ThemeData.dark().textTheme).apply(
      bodyColor:    AppColors.text,
      displayColor: AppColors.text,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor:  AppColors.bg,
      foregroundColor:  AppColors.text,
      elevation: 0,
      centerTitle: false,
      titleTextStyle: GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.text),
      shape: const Border(bottom: BorderSide(color: AppColors.border, width: 1)),
    ),
    bottomNavigationBarTheme: const BottomNavigationBarThemeData(
      backgroundColor:      AppColors.surface,
      selectedItemColor:    AppColors.cyan,
      unselectedItemColor:  AppColors.muted,
      type: BottomNavigationBarType.fixed,
      elevation: 0,
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: const Color(0x10FFFFFF),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.border)),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(10), borderSide: const BorderSide(color: AppColors.cyan)),
      hintStyle: const TextStyle(color: AppColors.dim),
      labelStyle: const TextStyle(color: AppColors.cyan, fontSize: 11, fontWeight: FontWeight.w600),
    ),
  );
}
