import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:async';
import 'dart:math';
import 'services/api_service.dart';
import 'utils/theme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const AttendanceApp());
}

class AttendanceApp extends StatelessWidget {
  const AttendanceApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Attendance Tracker',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      home: const SplashScreen(),
    );
  }
}

// ════════════════════════════════════════════════════════
// SPLASH
// ════════════════════════════════════════════════════════
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});
  @override State<SplashScreen> createState() => _SplashScreenState();
}
class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 800), () async {
      final ok = await ApiService.isLoggedIn();
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(
        builder: (_) => ok ? const MainScreen() : const LoginScreen(),
      ));
    });
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Text('⏱', style: TextStyle(fontSize: 60)),
      const SizedBox(height: 12),
      Text('Attendance Tracker', style: GoogleFonts.inter(fontSize: 24, fontWeight: FontWeight.w800, color: AppColors.cyan)),
    ])),
  );
}

// ════════════════════════════════════════════════════════
// LOGIN
// ════════════════════════════════════════════════════════
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override State<LoginScreen> createState() => _LoginScreenState();
}
class _LoginScreenState extends State<LoginScreen> {
  final _serverCtrl = TextEditingController(text: 'http://192.168.1.100:8000');
  final _userCtrl   = TextEditingController();
  final _passCtrl   = TextEditingController();
  bool _loading = false;
  String? _error;

  Future<void> _login() async {
    if (_serverCtrl.text.isEmpty || _userCtrl.text.isEmpty || _passCtrl.text.isEmpty) {
      setState(() => _error = 'All fields are required.');
      return;
    }
    setState(() { _loading = true; _error = null; });
    try {
      await ApiService.login(_serverCtrl.text.trim(), _userCtrl.text.trim(), _passCtrl.text);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainScreen()));
    } catch (e) {
      setState(() => _error = e.toString().replaceFirst('Exception: ', ''));
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(children: [
          const SizedBox(height: 60),
          const Text('⏱', style: TextStyle(fontSize: 56)),
          const SizedBox(height: 12),
          Text('Attendance Tracker', style: GoogleFonts.inter(fontSize: 28, fontWeight: FontWeight.w800, color: AppColors.cyan)),
          const SizedBox(height: 6),
          Text('Track your time, effortlessly', style: GoogleFonts.inter(fontSize: 14, color: AppColors.muted)),
          const SizedBox(height: 40),
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(20), border: Border.all(color: AppColors.border)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (_error != null) ...[
                Container(
                  padding: const EdgeInsets.all(12), margin: const EdgeInsets.only(bottom: 14),
                  decoration: BoxDecoration(color: AppColors.danger.withOpacity(0.1), borderRadius: BorderRadius.circular(8), border: Border.all(color: AppColors.danger.withOpacity(0.3))),
                  child: Text(_error!, style: const TextStyle(color: AppColors.danger, fontSize: 13)),
                ),
              ],
              _fieldLabel('SERVER URL'),
              TextField(controller: _serverCtrl, decoration: const InputDecoration(hintText: 'http://192.168.x.x:8000'), keyboardType: TextInputType.url, autocorrect: false),
              const SizedBox(height: 14),
              _fieldLabel('USERNAME'),
              TextField(controller: _userCtrl, decoration: const InputDecoration(hintText: 'username'), autocorrect: false, textCapitalization: TextCapitalization.none),
              const SizedBox(height: 14),
              _fieldLabel('PASSWORD'),
              TextField(controller: _passCtrl, decoration: const InputDecoration(hintText: '••••••••'), obscureText: true),
              const SizedBox(height: 20),
              SizedBox(width: double.infinity, height: 52,
                child: ElevatedButton(
                  onPressed: _loading ? null : _login,
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: const Color(0xFF020617), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                  child: _loading ? const CircularProgressIndicator(color: Color(0xFF020617), strokeWidth: 2) : Text('Sign In →', style: GoogleFonts.inter(fontSize: 16, fontWeight: FontWeight.w700)),
                ),
              ),
            ]),
          ),
          const SizedBox(height: 20),
          Text('Phone and server must be on the same network', style: GoogleFonts.inter(fontSize: 12, color: AppColors.dim), textAlign: TextAlign.center),
        ]),
      )),
    );
  }

  Widget _fieldLabel(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 6),
    child: Text(text, style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.cyan, letterSpacing: 1)),
  );
}

// ════════════════════════════════════════════════════════
// MAIN SCREEN — Bottom tabs
// ════════════════════════════════════════════════════════
class MainScreen extends StatefulWidget {
  const MainScreen({super.key});
  @override State<MainScreen> createState() => _MainScreenState();
}
class _MainScreenState extends State<MainScreen> {
  int _tab = 0;
  final _screens = const [DashboardScreen(), HistoryScreen(), LeavesScreen(), SettingsScreen()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_tab],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) => setState(() => _tab = i),
        items: const [
          BottomNavigationBarItem(icon: Text('🏠', style: TextStyle(fontSize: 22)), label: 'Home'),
          BottomNavigationBarItem(icon: Text('📅', style: TextStyle(fontSize: 22)), label: 'History'),
          BottomNavigationBarItem(icon: Text('🌿', style: TextStyle(fontSize: 22)), label: 'Leaves'),
          BottomNavigationBarItem(icon: Text('⚙️', style: TextStyle(fontSize: 22)), label: 'Settings'),
        ],
      ),
    );
  }
}

// ════════════════════════════════════════════════════════
// DASHBOARD
// ════════════════════════════════════════════════════════
class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override State<DashboardScreen> createState() => _DashboardScreenState();
}
class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic>? _record;
  bool _loading = true, _actionLoading = false;
  int  _elapsed = 0; // seconds
  double _weekTotal = 0; int _weekDays = 0, _weekRecorded = 0;
  Timer? _timer;
  String _username = '';

  @override
  void initState() {
    super.initState();
    _init();
  }
  @override
  void dispose() { _timer?.cancel(); super.dispose(); }

  Future<void> _init() async {
    _username = await ApiService.getUsername() ?? '';
    await _load();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final results = await Future.wait([ApiService.getTodayRecord(), ApiService.getWeekRecords()]);
      final rec  = results[0] as Map<String, dynamic>?;
      final week = results[1] as List<Map<String, dynamic>>;

      final completed = week.where((r) => r['check_in'] != null && r['check_out'] != null).toList();
      double wTotal = 0;
      for (final r in completed) {
        final ci = DateTime.parse(r['check_in']!);
        final co = DateTime.parse(r['check_out']!);
        wTotal += max(co.difference(ci).inSeconds / 3600.0, 0);
      }

      setState(() {
        _record      = rec?.isEmpty == true ? null : rec;
        _weekTotal   = wTotal;
        _weekDays    = completed.length;
        _weekRecorded = week.length;
        _loading     = false;
      });

      if (_record?['check_in'] != null && _record?['check_out'] == null) {
        _startTimer(DateTime.parse(_record!['check_in']));
      } else {
        _timer?.cancel();
        if (_record?['check_in'] != null && _record?['check_out'] != null) {
          final ci = DateTime.parse(_record!['check_in']!);
          final co = DateTime.parse(_record!['check_out']!);
          setState(() => _elapsed = max(co.difference(ci).inSeconds, 0));
        }
      }
    } catch (e) {
      setState(() => _loading = false);
      _showError('Failed to load: $e');
    }
  }

  void _startTimer(DateTime checkIn) {
    _timer?.cancel();
    void tick() => setState(() => _elapsed = max(DateTime.now().difference(checkIn).inSeconds, 0));
    tick();
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => tick());
  }

  Future<void> _handleAction() async {
    setState(() => _actionLoading = true);
    try {
      if (_record?['check_in'] == null) {
        final updated = await ApiService.checkIn(recordId: _record?['id']);
        setState(() => _record = updated);
        _startTimer(DateTime.parse(updated['check_in']));
      } else if (_record?['check_out'] == null) {
        final updated = await ApiService.checkOut(_record!['id']);
        setState(() => _record = updated);
        _timer?.cancel();
        final ci = DateTime.parse(updated['check_in']);
        final co = DateTime.parse(updated['check_out']);
        setState(() => _elapsed = max(co.difference(ci).inSeconds, 0));
        await _load();
      }
    } catch (e) { _showError('Action failed: $e'); }
    setState(() => _actionLoading = false);
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: AppColors.danger));
  }

  void _openManualModal() {
    String ciVal = '', coVal = '';
    if (_record?['check_in'] != null) {
      final t = DateTime.parse(_record!['check_in']).toLocal();
      ciVal = '${t.hour.toString().padLeft(2,'0')}:${t.minute.toString().padLeft(2,'0')}';
    }
    if (_record?['check_out'] != null) {
      final t = DateTime.parse(_record!['check_out']).toLocal();
      coVal = '${t.hour.toString().padLeft(2,'0')}:${t.minute.toString().padLeft(2,'0')}';
    }
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _ManualTimeSheet(
        initialIn: ciVal, initialOut: coVal,
        onSave: (ci, co) async {
          if (ci.isNotEmpty && co.isNotEmpty) {
            final h1 = int.parse(ci.split(':')[0]), m1 = int.parse(ci.split(':')[1]);
            final h2 = int.parse(co.split(':')[0]), m2 = int.parse(co.split(':')[1]);
            if ((h2*60+m2) <= (h1*60+m1)) { _showError('Check-out must be after check-in'); return; }
          }
          setState(() => _actionLoading = true);
          try {
            final updated = await ApiService.setManualTime(recordId: _record?['id'], checkIn: ci, checkOut: co);
            setState(() { _record = updated; _actionLoading = false; });
            await _load();
          } catch (e) { setState(() => _actionLoading = false); _showError('Save failed: $e'); }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isIn  = _record?['check_in']  != null;
    final isOut = _record?['check_out'] != null;
    final target = 9 * 3600;
    final remaining = max(target - _elapsed, 0);
    final weekTarget = 5 * 9.0;
    final weekPct = min((_weekTotal / weekTarget * 100).round(), 100);

    String greeting() {
      final h = DateTime.now().hour;
      return h < 12 ? 'morning' : h < 17 ? 'afternoon' : 'evening';
    }

    return Scaffold(
      appBar: AppBar(
        title: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Good ${greeting()} 👋', style: GoogleFonts.inter(fontSize: 18, fontWeight: FontWeight.w700)),
          Text(DateTime.now().toString().substring(0,10), style: GoogleFonts.inter(fontSize: 12, color: AppColors.muted)),
        ]),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 16, top: 8, bottom: 8),
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              color: AppColors.cyan.withOpacity(0.12),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: AppColors.cyan.withOpacity(0.2)),
            ),
            alignment: Alignment.center,
            child: Text(_username, style: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.cyan)),
          ),
        ],
      ),
      body: _loading
        ? const Center(child: CircularProgressIndicator(color: AppColors.cyan))
        : RefreshIndicator(
            color: AppColors.cyan,
            backgroundColor: AppColors.card,
            onRefresh: _load,
            child: SingleChildScrollView(
              physics: const AlwaysScrollableScrollPhysics(),
              padding: const EdgeInsets.all(16),
              child: Column(children: [
                // ── Hero Card ──
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: AppColors.cyan.withOpacity(0.06),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: AppColors.cyan.withOpacity(0.25)),
                  ),
                  child: Column(children: [
                    Text(
                      isIn ? ApiService.secToHHMM(_elapsed) : '--:--',
                      style: GoogleFonts.inter(fontSize: 64, fontWeight: FontWeight.w800, color: AppColors.cyan, letterSpacing: -2, fontFeatures: [const FontFeature.tabularFigures()]),
                    ),
                    Text(
                      isOut ? 'SESSION COMPLETE' : isIn ? 'ELAPSED' : 'SESSION DURATION',
                      style: GoogleFonts.inter(fontSize: 11, color: AppColors.muted, fontWeight: FontWeight.w600, letterSpacing: 1),
                    ),
                    const SizedBox(height: 12),
                    // Status pill
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: (isIn && !isOut) ? AppColors.emerald.withOpacity(0.1) : AppColors.muted.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: (isIn && !isOut) ? AppColors.emerald.withOpacity(0.2) : AppColors.muted.withOpacity(0.2)),
                      ),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Container(width: 7, height: 7, decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: (isIn && !isOut) ? AppColors.emerald : AppColors.muted,
                        )),
                        const SizedBox(width: 6),
                        Text(
                          isOut ? 'Session Complete' : isIn ? 'Session Active' : 'Not Started',
                          style: GoogleFonts.inter(fontSize: 12, fontWeight: FontWeight.w600,
                            color: (isIn && !isOut) ? AppColors.emerald : AppColors.muted),
                        ),
                      ]),
                    ),
                    const SizedBox(height: 18),
                    // Action button
                    if (_actionLoading)
                      const CircularProgressIndicator(color: AppColors.cyan)
                    else if (!isIn)
                      _actionButton('▶  Start Session', AppColors.cyan, const Color(0xFF020617), _handleAction)
                    else if (!isOut)
                      _actionButton('⏹  End Session', AppColors.danger, Colors.white, _handleAction),
                    if (isIn) ...[
                      const SizedBox(height: 10),
                      TextButton(
                        onPressed: _openManualModal,
                        style: TextButton.styleFrom(
                          foregroundColor: AppColors.muted,
                          backgroundColor: AppColors.border,
                          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                        ),
                        child: const Text('✏️  Edit Time'),
                      ),
                    ],
                    // Remaining
                    if (isIn && !isOut) ...[
                      const SizedBox(height: 16),
                      Divider(color: AppColors.border, thickness: 1),
                      const SizedBox(height: 12),
                      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('Remaining', style: GoogleFonts.inter(fontSize: 11, color: AppColors.muted)),
                          Text(ApiService.secToHHMM(remaining),
                            style: GoogleFonts.inter(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.amber, fontFeatures: [const FontFeature.tabularFigures()])),
                        ]),
                        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                          Text('Suggested checkout', style: GoogleFonts.inter(fontSize: 11, color: AppColors.muted)),
                          if (_record?['check_in'] != null)
                            Builder(builder: (_) {
                              final exp = DateTime.parse(_record!['check_in']).toLocal().add(const Duration(hours: 9));
                              return Text(
                                '${exp.hour.toString().padLeft(2,'0')}:${exp.minute.toString().padLeft(2,'0')}',
                                style: GoogleFonts.inter(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.cyan),
                              );
                            }),
                        ]),
                      ]),
                    ],
                  ]),
                ),
                const SizedBox(height: 14),
                // ── Week Stats ──
                Row(children: [
                  Expanded(child: _statCard(ApiService.hoursToHHMM(_weekTotal), 'Weekly Hours', 'Target: ${(5*9)}h', AppColors.cyan, weekPct / 100)),
                  const SizedBox(width: 12),
                  Expanded(child: _statCard('$_weekDays/$_weekRecorded', 'Days This Week',
                    '${_weekRecorded > 0 ? min((_weekDays/_weekRecorded*100).round(),100) : 0}% complete',
                    AppColors.emerald,
                    _weekRecorded > 0 ? min(_weekDays / _weekRecorded, 1.0) : 0)),
                ]),
              ]),
            ),
          ),
    );
  }

  Widget _actionButton(String label, Color bg, Color fg, VoidCallback onTap) =>
    SizedBox(width: double.infinity, height: 56,
      child: ElevatedButton(
        onPressed: onTap,
        style: ElevatedButton.styleFrom(backgroundColor: bg, foregroundColor: fg,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
        child: Text(label, style: GoogleFonts.inter(fontSize: 17, fontWeight: FontWeight.w700)),
      ),
    );

  Widget _statCard(String val, String label, String sub, Color color, double pct) =>
    Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(val, style: GoogleFonts.inter(fontSize: 24, fontWeight: FontWeight.w800, color: color, fontFeatures: [const FontFeature.tabularFigures()])),
        Text(label, style: GoogleFonts.inter(fontSize: 10, color: AppColors.muted, letterSpacing: 0.8)),
        Text(sub,   style: GoogleFonts.inter(fontSize: 11, color: AppColors.dim)),
        const SizedBox(height: 8),
        ClipRRect(borderRadius: BorderRadius.circular(2),
          child: LinearProgressIndicator(value: pct, backgroundColor: AppColors.border, color: color, minHeight: 3)),
      ]),
    );
}

// ════════════════════════════════════════════════════════
// MANUAL TIME BOTTOM SHEET
// ════════════════════════════════════════════════════════
class _ManualTimeSheet extends StatefulWidget {
  final String initialIn, initialOut;
  final Future<void> Function(String ci, String co) onSave;
  const _ManualTimeSheet({required this.initialIn, required this.initialOut, required this.onSave});
  @override State<_ManualTimeSheet> createState() => _ManualTimeSheetState();
}
class _ManualTimeSheetState extends State<_ManualTimeSheet> {
  late final _ciCtrl = TextEditingController(text: widget.initialIn);
  late final _coCtrl = TextEditingController(text: widget.initialOut);
  bool _saving = false;

  String _durPreview() {
    if (_ciCtrl.text.isEmpty || _coCtrl.text.isEmpty) return '';
    try {
      final p1 = _ciCtrl.text.split(':'); final p2 = _coCtrl.text.split(':');
      final diff = (int.parse(p2[0])*60+int.parse(p2[1])) - (int.parse(p1[0])*60+int.parse(p1[1]));
      if (diff <= 0) return '⚠ Invalid';
      return '${diff~/60}h ${diff%60}m';
    } catch (_) { return ''; }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(left: 20, right: 20, top: 20, bottom: MediaQuery.of(context).viewInsets.bottom + 30),
      decoration: BoxDecoration(color: AppColors.surface, borderRadius: const BorderRadius.vertical(top: Radius.circular(20)), border: Border.all(color: AppColors.border)),
      child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Center(child: Container(width: 36, height: 4, decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(2)))),
        const SizedBox(height: 16),
        Text("Edit Today's Time", style: GoogleFonts.inter(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.text)),
        const SizedBox(height: 14),
        // Presets
        Wrap(spacing: 8, children: [
          _preset("Standard 9–6", "09:00", "18:00"),
          _preset("Half Day", "09:00", "13:00"),
          _preset("Clear", "", ""),
        ]),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('CHECK-IN', style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.cyan, letterSpacing: 1)),
            const SizedBox(height: 6),
            TextField(controller: _ciCtrl, onChanged: (_) => setState((){}), decoration: const InputDecoration(hintText: '09:00'), keyboardType: TextInputType.datetime),
          ])),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('CHECK-OUT', style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.cyan, letterSpacing: 1)),
            const SizedBox(height: 6),
            TextField(controller: _coCtrl, onChanged: (_) => setState((){}), decoration: const InputDecoration(hintText: '18:00'), keyboardType: TextInputType.datetime),
          ])),
        ]),
        const SizedBox(height: 10),
        if (_durPreview().isNotEmpty)
          Center(child: Text('Duration: ${_durPreview()}',
            style: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.w600,
              color: _durPreview().contains('⚠') ? AppColors.danger : AppColors.emerald))),
        const SizedBox(height: 14),
        SizedBox(width: double.infinity, height: 50,
          child: ElevatedButton(
            onPressed: _saving ? null : () async {
              setState(() => _saving = true);
              await widget.onSave(_ciCtrl.text, _coCtrl.text);
              if (mounted) Navigator.pop(context);
            },
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: const Color(0xFF020617), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            child: _saving ? const CircularProgressIndicator(color: Color(0xFF020617), strokeWidth: 2) : Text('Save Time', style: GoogleFonts.inter(fontWeight: FontWeight.w700, fontSize: 15)),
          ),
        ),
        TextButton(onPressed: () => Navigator.pop(context), child: Center(child: Text('Cancel', style: GoogleFonts.inter(color: AppColors.muted)))),
      ]),
    );
  }

  Widget _preset(String label, String ci, String co) => ActionChip(
    label: Text(label, style: GoogleFonts.inter(fontSize: 12, color: AppColors.cyan, fontWeight: FontWeight.w600)),
    onPressed: () { setState(() { _ciCtrl.text = ci; _coCtrl.text = co; }); },
    backgroundColor: AppColors.cyan.withOpacity(0.1),
    side: BorderSide(color: AppColors.cyan.withOpacity(0.2)),
    padding: const EdgeInsets.symmetric(horizontal: 4),
  );
}

// ════════════════════════════════════════════════════════
// HISTORY
// ════════════════════════════════════════════════════════
class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override State<HistoryScreen> createState() => _HistoryScreenState();
}
class _HistoryScreenState extends State<HistoryScreen> {
  final now = DateTime.now();
  late int _year = DateTime.now().year, _month = DateTime.now().month;
  List<Map<String,dynamic>> _records = [];
  bool _loading = true;
  static const _months = ['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

  @override void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() => _loading = true);
    try {
      final data = await ApiService.getMonthRecords(_year, _month);
      setState(() { _records = data; _loading = false; });
    } catch (_) { setState(() => _loading = false); }
  }

  void _prev() { setState(() { if (_month==1){_month=12;_year--;} else _month--; }); _load(); }
  void _next() { setState(() { if (_month==12){_month=1;_year++;} else _month++; }); _load(); }

  @override
  Widget build(BuildContext context) {
    final worked = _records.where((r) => r['check_in']!=null && r['check_out']!=null).toList();
    final leaves = _records.where((r) => r['leave_type']!=null).toList();
    double totalH = 0;
    for (final r in worked) {
      totalH += max((DateTime.parse(r['check_out']!).difference(DateTime.parse(r['check_in']!))).inSeconds/3600.0, 0);
    }

    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          IconButton(icon: const Icon(Icons.chevron_left), onPressed: _prev, color: AppColors.text),
          Text('${_months[_month]} $_year', style: GoogleFonts.inter(fontWeight: FontWeight.w700)),
          IconButton(icon: const Icon(Icons.chevron_right), onPressed: _next, color: AppColors.text),
        ]),
      ),
      body: Column(children: [
        // Summary row
        Container(
          color: AppColors.surface,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(children: [
            _summCard('${worked.length}', 'Present', AppColors.emerald),
            _summCard('${leaves.length}', 'Leaves',  AppColors.amber),
            _summCard(ApiService.hoursToHHMM(totalH), 'Hours',   AppColors.cyan),
          ]),
        ),
        if (_loading)
          const Expanded(child: Center(child: CircularProgressIndicator(color: AppColors.cyan)))
        else
          Expanded(child: RefreshIndicator(
            color: AppColors.cyan, backgroundColor: AppColors.card, onRefresh: _load,
            child: _records.isEmpty
              ? const Center(child: Text('No records', style: TextStyle(color: AppColors.muted)))
              : ListView.separated(
                  padding: const EdgeInsets.all(12),
                  itemCount: _records.length,
                  separatorBuilder: (_, __) => const Divider(color: Color(0x08FFFFFF), height: 1),
                  itemBuilder: (_, i) {
                    final r   = _records[i];
                    final d   = DateTime.parse(r['date']);
                    final dow = ['','Mon','Tue','Wed','Thu','Fri','Sat','Sun'][d.weekday];
                    String timeStr = 'No record'; String dur = ''; Color dotColor = AppColors.dim;
                    if (r['leave_type'] != null) { timeStr = r['leave_type']; dotColor = AppColors.amber; }
                    else if (r['check_in'] != null && r['check_out'] != null) {
                      final ci = DateTime.parse(r['check_in']!).toLocal();
                      final co = DateTime.parse(r['check_out']!).toLocal();
                      timeStr = '${_t(ci)} → ${_t(co)}';
                      dur = ApiService.hoursToHHMM(max(co.difference(ci).inSeconds/3600.0,0));
                      dotColor = AppColors.emerald;
                    } else if (r['check_in'] != null) {
                      timeStr = '${_t(DateTime.parse(r['check_in']!).toLocal())} → Active';
                      dotColor = AppColors.emerald;
                    }
                    return Padding(
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      child: Row(children: [
                        Container(width: 44, height: 44, decoration: BoxDecoration(color: dotColor.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
                          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                            Text('${d.day}', style: GoogleFonts.inter(fontSize: 15, fontWeight: FontWeight.w800, color: dotColor)),
                            Text(dow, style: GoogleFonts.inter(fontSize: 9, fontWeight: FontWeight.w600, color: dotColor)),
                          ])),
                        const SizedBox(width: 12),
                        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text('${_months[d.month]} ${d.day}, ${d.year}', style: GoogleFonts.inter(fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.text)),
                          Text(timeStr, style: GoogleFonts.inter(fontSize: 11, color: AppColors.muted)),
                        ])),
                        if (dur.isNotEmpty)
                          Text(dur, style: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.cyan, fontFeatures: [const FontFeature.tabularFigures()])),
                      ]),
                    );
                  },
                ),
          )),
      ]),
    );
  }

  String _t(DateTime d) => '${d.hour.toString().padLeft(2,'0')}:${d.minute.toString().padLeft(2,'0')}';

  Widget _summCard(String val, String label, Color color) => Expanded(child:
    Container(margin: const EdgeInsets.symmetric(horizontal: 4), padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(10), border: Border.all(color: AppColors.border)),
      child: Column(children: [
        Text(val,   style: GoogleFonts.inter(fontSize: 20, fontWeight: FontWeight.w800, color: color, fontFeatures: [const FontFeature.tabularFigures()])),
        Text(label, style: GoogleFonts.inter(fontSize: 10, color: AppColors.muted, letterSpacing: 0.5)),
      ])));
}

// ════════════════════════════════════════════════════════
// LEAVES & EARNINGS (Simplified Flutter version)
// ════════════════════════════════════════════════════════
class LeavesScreen extends StatefulWidget {
  const LeavesScreen({super.key});
  @override State<LeavesScreen> createState() => _LeavesScreenState();
}
class _LeavesScreenState extends State<LeavesScreen> {
  static const _leaveTypes = {
    'casual':      {'label': 'Casual Leave',    'default': 13.5, 'color': AppColors.cyan},
    'earned':      {'label': 'Earned Leave',    'default': 0.0,  'color': AppColors.emerald},
    'sick':        {'label': 'Sick Leave',      'default': 5.0,  'color': AppColors.amber},
    'paternity':   {'label': 'Paternity Leave', 'default': 6.0,  'color': AppColors.purple},
    'loss_of_pay': {'label': 'Loss of Pay',     'default': 0.0,  'color': AppColors.danger},
    'comp_off':    {'label': 'Comp-Off',        'default': 0.0,  'color': AppColors.amber},
  };

  Map<String,Map<String,double>> _balances = {};
  double _dailyRate = 250, _satRate = 250;
  String _satMode = 'pay';
  String? _editing;
  final Map<String, TextEditingController> _eCtrl = {}, _uCtrl = {}, _cCtrl = {};
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final map = <String, Map<String,double>>{};
    for (final k in _leaveTypes.keys) {
      map[k] = {
        'entitled': prefs.getDouble('lb_${k}_entitled') ?? (_leaveTypes[k]!['default'] as double),
        'used':     prefs.getDouble('lb_${k}_used')     ?? 0.0,
        'carried':  prefs.getDouble('lb_${k}_carried')  ?? 0.0,
      };
    }
    setState(() {
      _balances   = map;
      _dailyRate  = prefs.getDouble('dailyRate') ?? 250;
      _satRate    = prefs.getDouble('satRate')   ?? 250;
      _satMode    = prefs.getString('satMode')   ?? 'pay';
      _loading    = false;
    });
  }

  Future<void> _saveBalance(String type) async {
    final prefs  = await SharedPreferences.getInstance();
    final ent    = double.tryParse(_eCtrl[type]?.text ?? '') ?? 0;
    final used   = double.tryParse(_uCtrl[type]?.text ?? '') ?? 0;
    final carried= double.tryParse(_cCtrl[type]?.text ?? '') ?? 0;
    await prefs.setDouble('lb_${type}_entitled', ent);
    await prefs.setDouble('lb_${type}_used',     used);
    await prefs.setDouble('lb_${type}_carried',  carried);
    setState(() { _balances[type] = {'entitled': ent, 'used': used, 'carried': carried}; _editing = null; });
  }

  Future<void> _saveConfig() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble('dailyRate', _dailyRate);
    await prefs.setDouble('satRate',   _satRate);
    await prefs.setString('satMode',   _satMode);
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Configuration saved'), backgroundColor: AppColors.emerald));
  }

  double _avail(String type) {
    final b = _balances[type] ?? {'entitled':0,'used':0,'carried':0};
    return ((b['entitled']??0) + (b['carried']??0) - (b['used']??0));
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator(color: AppColors.cyan)));
    return Scaffold(
      appBar: AppBar(title: const Text('Leaves & Earnings')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _sectionLabel('LEAVE BALANCES'),
        ..._leaveTypes.entries.map((e) {
          final type  = e.key;
          final meta  = e.value;
          final avail = _avail(type);
          final b     = _balances[type]!;
          final isEditing = _editing == type;
          final color = meta['color'] as Color;

          if (isEditing) {
            _eCtrl[type] ??= TextEditingController(text: b['entitled'].toString());
            _uCtrl[type] ??= TextEditingController(text: b['used'].toString());
            _cCtrl[type] ??= TextEditingController(text: b['carried'].toString());
          }

          return Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(meta['label'] as String, style: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.text)),
                  Text('${b['used']} used · ${b['entitled']} entitled', style: GoogleFonts.inter(fontSize: 11, color: AppColors.muted)),
                ])),
                Text('$avail', style: GoogleFonts.inter(fontSize: 26, fontWeight: FontWeight.w800, color: avail > 0 ? color : avail < 0 ? AppColors.danger : AppColors.muted, fontFeatures: [const FontFeature.tabularFigures()])),
                const SizedBox(width: 10),
                GestureDetector(
                  onTap: () => setState(() => _editing = isEditing ? null : type),
                  child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(6), border: Border.all(color: color.withOpacity(0.2))),
                    child: Text(isEditing ? 'Close' : '✏️', style: GoogleFonts.inter(fontSize: 12, color: color, fontWeight: FontWeight.w600)),
                  ),
                ),
              ]),
              if (b['entitled']! > 0) ...[
                const SizedBox(height: 8),
                ClipRRect(borderRadius: BorderRadius.circular(2),
                  child: LinearProgressIndicator(value: min((b['used']!/(b['entitled']!)).clamp(0,1), 1), backgroundColor: AppColors.border, color: color, minHeight: 3)),
              ],
              if (isEditing) ...[
                const SizedBox(height: 14),
                Divider(color: AppColors.border),
                const SizedBox(height: 10),
                Row(children: [
                  _editField('Entitled', _eCtrl[type]!),
                  const SizedBox(width: 8),
                  _editField('Used', _uCtrl[type]!),
                  const SizedBox(width: 8),
                  _editField('Carry-over', _cCtrl[type]!),
                ]),
                const SizedBox(height: 10),
                Row(children: [
                  Expanded(child: ElevatedButton(
                    onPressed: () => _saveBalance(type),
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: const Color(0xFF020617), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                    child: const Text('Save'),
                  )),
                  const SizedBox(width: 8),
                  Expanded(child: OutlinedButton(
                    onPressed: () async {
                      final prefs = await SharedPreferences.getInstance();
                      final def = _leaveTypes[type]!['default'] as double;
                      await prefs.setDouble('lb_${type}_entitled', def);
                      await prefs.setDouble('lb_${type}_used', 0);
                      await prefs.setDouble('lb_${type}_carried', 0);
                      setState(() { _balances[type] = {'entitled': def, 'used': 0, 'carried': 0}; _editing = null; });
                    },
                    style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger, side: const BorderSide(color: AppColors.danger), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8))),
                    child: const Text('Reset'),
                  )),
                ]),
              ],
            ]),
          );
        }),

        const SizedBox(height: 24),
        _sectionLabel('CONFIGURE EARNINGS'),
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text('Daily Rate (₹ / weekday)', style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.cyan, letterSpacing: 0.8)),
            const SizedBox(height: 6),
            TextField(
              controller: TextEditingController(text: _dailyRate.toString()),
              onChanged: (v) => _dailyRate = double.tryParse(v) ?? 250,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(hintText: '250'),
            ),
            const SizedBox(height: 14),
            Text('Saturday Mode', style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.cyan, letterSpacing: 0.8)),
            const SizedBox(height: 8),
            Row(children: [
              for (final opt in [['pay','Pay'],['comp_off','Comp-Off']])
                Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(
                  label: Text(opt[1]),
                  selected: _satMode == opt[0],
                  onSelected: (_) => setState(() => _satMode = opt[0]),
                  selectedColor: AppColors.cyan,
                  labelStyle: GoogleFonts.inter(color: _satMode==opt[0] ? const Color(0xFF020617) : AppColors.muted, fontWeight: FontWeight.w600),
                  backgroundColor: AppColors.border,
                  side: BorderSide.none,
                )),
            ]),
            if (_satMode == 'pay') ...[
              const SizedBox(height: 14),
              Text('Saturday Rate (₹)', style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.cyan, letterSpacing: 0.8)),
              const SizedBox(height: 6),
              TextField(
                controller: TextEditingController(text: _satRate.toString()),
                onChanged: (v) => _satRate = double.tryParse(v) ?? 250,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(hintText: '250'),
              ),
            ],
            const SizedBox(height: 16),
            SizedBox(width: double.infinity, height: 48,
              child: ElevatedButton(
                onPressed: _saveConfig,
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.cyan, foregroundColor: const Color(0xFF020617), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
                child: Text('Save Configuration', style: GoogleFonts.inter(fontWeight: FontWeight.w700)),
              ),
            ),
          ]),
        ),
      ]),
    );
  }

  Widget _sectionLabel(String text) => Padding(
    padding: const EdgeInsets.only(bottom: 10),
    child: Text(text, style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.muted, letterSpacing: 1)),
  );

  Widget _editField(String label, TextEditingController ctrl) => Expanded(child: Column(
    crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(label, style: GoogleFonts.inter(fontSize: 10, color: AppColors.cyan, fontWeight: FontWeight.w600)),
      const SizedBox(height: 4),
      TextField(controller: ctrl, keyboardType: TextInputType.number, textAlign: TextAlign.center,
        decoration: const InputDecoration(contentPadding: EdgeInsets.symmetric(vertical: 8, horizontal: 8)),
        style: GoogleFonts.inter(fontSize: 14, color: AppColors.text)),
    ]));
}

// ════════════════════════════════════════════════════════
// SETTINGS
// ════════════════════════════════════════════════════════
class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});
  @override State<SettingsScreen> createState() => _SettingsScreenState();
}
class _SettingsScreenState extends State<SettingsScreen> {
  String _user = '', _server = '';

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final u = await ApiService.getUsername();
    final s = await ApiService.getServerUrl();
    setState(() { _user = u ?? ''; _server = s; });
  }

  void _logout() {
    showDialog(context: context, builder: (_) => AlertDialog(
      backgroundColor: AppColors.card,
      title: Text('Sign Out', style: GoogleFonts.inter(color: AppColors.text, fontWeight: FontWeight.w700)),
      content: Text('Are you sure?', style: GoogleFonts.inter(color: AppColors.muted)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: Text('Cancel', style: GoogleFonts.inter(color: AppColors.muted))),
        TextButton(
          onPressed: () async {
            await ApiService.logout();
            if (!mounted) return;
            Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false);
          },
          child: Text('Sign Out', style: GoogleFonts.inter(color: AppColors.danger, fontWeight: FontWeight.w700)),
        ),
      ],
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        _section('Account', [
          _row('Username', _user, trailing: _chip('Active', AppColors.emerald)),
          _row('Server', _server),
          const SizedBox(height: 12),
          Container(margin: const EdgeInsets.symmetric(horizontal: 0),
            child: OutlinedButton(
              onPressed: _logout,
              style: OutlinedButton.styleFrom(foregroundColor: AppColors.danger, side: BorderSide(color: AppColors.danger.withOpacity(0.3)),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)), padding: const EdgeInsets.symmetric(vertical: 12)),
              child: Text('Sign Out', style: GoogleFonts.inter(fontWeight: FontWeight.w700)),
            )),
        ]),
        const SizedBox(height: 24),
        _section('About', [
          _row('Attendance Tracker', 'Version 1.0.0'),
          _row('Built for', 'attendacetracker.duckdns.org'),
        ]),
      ]),
    );
  }

  Widget _section(String title, List<Widget> children) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(title.toUpperCase(), style: GoogleFonts.inter(fontSize: 11, fontWeight: FontWeight.w600, color: AppColors.muted, letterSpacing: 1)),
    const SizedBox(height: 10),
    Container(
      decoration: BoxDecoration(color: AppColors.card, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.border)),
      padding: const EdgeInsets.all(14),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: children),
    ),
  ]);

  Widget _row(String label, String val, {Widget? trailing}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 8),
    child: Row(children: [
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600, color: AppColors.text)),
        if (val.isNotEmpty) Text(val, style: GoogleFonts.inter(fontSize: 12, color: AppColors.muted)),
      ])),
      if (trailing != null) trailing,
    ]),
  );

  Widget _chip(String text, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
    decoration: BoxDecoration(color: color.withOpacity(0.12), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.2))),
    child: Text(text, style: GoogleFonts.inter(fontSize: 11, color: color, fontWeight: FontWeight.w700)),
  );
}
