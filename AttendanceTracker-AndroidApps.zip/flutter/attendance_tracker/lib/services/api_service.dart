import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  static const _tokenKey   = 'accessToken';
  static const _refreshKey = 'refreshToken';
  static const _serverKey  = 'serverUrl';
  static const _userKey    = 'username';

  // ── Persist helpers ────────────────────────────────────
  static Future<String> get _baseUrl async {
    final prefs = await SharedPreferences.getInstance();
    return (prefs.getString(_serverKey) ?? '').replaceAll(RegExp(r'/$'), '');
  }

  static Future<String?> get _token async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey);
  }

  static Future<Map<String, String>> get _authHeaders async {
    final token = await _token;
    return {
      'Content-Type': 'application/json',
      if (token != null) 'Authorization': 'Bearer $token',
    };
  }

  // ── Auth ──────────────────────────────────────────────
  static Future<void> login(String serverUrl, String username, String password) async {
    final url = serverUrl.replaceAll(RegExp(r'/$'), '');
    final res = await http.post(
      Uri.parse('$url/api/token/'),
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'username': username, 'password': password}),
    );
    if (res.statusCode != 200) {
      final body = jsonDecode(res.body);
      throw Exception(body['detail'] ?? 'Login failed');
    }
    final data = jsonDecode(res.body);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_serverKey,  url);
    await prefs.setString(_tokenKey,   data['access']);
    await prefs.setString(_refreshKey, data['refresh']);
    await prefs.setString(_userKey,    username);
  }

  static Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_tokenKey);
    await prefs.remove(_refreshKey);
    await prefs.remove(_userKey);
    await prefs.remove(_serverKey);
  }

  static Future<bool> isLoggedIn() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_tokenKey) != null;
  }

  static Future<String?> getUsername() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_userKey);
  }

  static Future<String> getServerUrl() async => await _baseUrl;

  // ── Refresh token ─────────────────────────────────────
  static Future<bool> _refreshToken() async {
    try {
      final prefs   = await SharedPreferences.getInstance();
      final refresh = prefs.getString(_refreshKey);
      final base    = await _baseUrl;
      if (refresh == null) return false;
      final res = await http.post(
        Uri.parse('$base/api/token/refresh/'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'refresh': refresh}),
      );
      if (res.statusCode != 200) return false;
      final data = jsonDecode(res.body);
      await prefs.setString(_tokenKey, data['access']);
      return true;
    } catch (_) { return false; }
  }

  // ── Generic request with auto-retry ──────────────────
  static Future<dynamic> _request(String method, String path, {Map<String, dynamic>? body}) async {
    final base    = await _baseUrl;
    final headers = await _authHeaders;
    final uri     = Uri.parse('$base$path');

    http.Response res;
    res = await _send(method, uri, headers, body);

    if (res.statusCode == 401) {
      final ok = await _refreshToken();
      if (ok) {
        final h2 = await _authHeaders;
        res = await _send(method, uri, h2, body);
      } else {
        throw Exception('Session expired. Please login again.');
      }
    }

    if (res.statusCode >= 400) {
      throw Exception('Request failed: ${res.statusCode}');
    }

    if (res.body.isEmpty) return null;
    return jsonDecode(res.body);
  }

  static Future<http.Response> _send(String method, Uri uri, Map<String, String> headers, Map<String, dynamic>? body) {
    final encoded = body != null ? jsonEncode(body) : null;
    switch (method) {
      case 'POST':   return http.post(uri,   headers: headers, body: encoded);
      case 'PATCH':  return http.patch(uri,  headers: headers, body: encoded);
      case 'DELETE': return http.delete(uri, headers: headers);
      default:       return http.get(uri,    headers: headers);
    }
  }

  // ── Attendance ────────────────────────────────────────
  static Future<Map<String, dynamic>?> getTodayRecord() async {
    final today = _fmtDate(DateTime.now());
    final data  = await _request('GET', '/api/v1/attendance/?date=$today');
    final list  = (data is Map ? data['results'] : data) as List? ?? [];
    return list.cast<Map<String, dynamic>>().firstWhere((r) => r['date'] == today, orElse: () => {});
  }

  static Future<Map<String, dynamic>> checkIn({int? recordId}) async {
    final now   = DateTime.now().toUtc().toIso8601String();
    final today = _fmtDate(DateTime.now());
    if (recordId != null) {
      return (await _request('PATCH', '/api/v1/attendance/$recordId/', body: {'check_in': now})) as Map<String, dynamic>;
    }
    return (await _request('POST', '/api/v1/attendance/', body: {'date': today, 'check_in': now})) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> checkOut(int recordId) async {
    final now = DateTime.now().toUtc().toIso8601String();
    return (await _request('PATCH', '/api/v1/attendance/$recordId/', body: {'check_out': now})) as Map<String, dynamic>;
  }

  static Future<Map<String, dynamic>> setManualTime({
    int? recordId, String? checkIn, String? checkOut, String? date,
  }) async {
    final d = date ?? _fmtDate(DateTime.now());
    final payload = <String, dynamic>{};
    if (checkIn  != null && checkIn.isNotEmpty)  payload['check_in']  = DateTime.parse('${d}T$checkIn:00').toUtc().toIso8601String();
    if (checkOut != null && checkOut.isNotEmpty) payload['check_out'] = DateTime.parse('${d}T$checkOut:00').toUtc().toIso8601String();
    if (recordId != null) {
      return (await _request('PATCH', '/api/v1/attendance/$recordId/', body: payload)) as Map<String, dynamic>;
    }
    payload['date'] = d;
    return (await _request('POST', '/api/v1/attendance/', body: payload)) as Map<String, dynamic>;
  }

  static Future<List<Map<String, dynamic>>> getMonthRecords(int year, int month) async {
    final m    = month.toString().padLeft(2, '0');
    final data = await _request('GET', '/api/v1/attendance/?date__gte=$year-$m-01&ordering=-date&limit=31');
    final list = (data is Map ? data['results'] : data) as List? ?? [];
    return list.cast<Map<String, dynamic>>();
  }

  static Future<List<Map<String, dynamic>>> getWeekRecords() async {
    final today = DateTime.now();
    final diff  = today.weekday == 7 ? -6 : 1 - today.weekday;
    final start = today.add(Duration(days: diff));
    final data  = await _request('GET',
      '/api/v1/attendance/?date__gte=${_fmtDate(start)}&date__lte=${_fmtDate(today)}');
    final list  = (data is Map ? data['results'] : data) as List? ?? [];
    return list.cast<Map<String, dynamic>>();
  }

  // ── Helpers ───────────────────────────────────────────
  static String _fmtDate(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2,'0')}-${d.day.toString().padLeft(2,'0')}';

  static String secToHHMM(int secs) {
    final s = secs.clamp(0, 999999);
    final h = s ~/ 3600;
    final m = (s % 3600) ~/ 60;
    return '${h.toString().padLeft(2,'0')}:${m.toString().padLeft(2,'0')}';
  }

  static String hoursToHHMM(double hours) => secToHHMM((hours * 3600).round());
}
