import React from 'react';
import { StatusBar, View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import { AuthProvider, useAuth } from './src/context/AuthContext';
import LoginScreen    from './src/screens/LoginScreen';
import DashboardScreen from './src/screens/DashboardScreen';
import HistoryScreen  from './src/screens/HistoryScreen';
import LeavesScreen   from './src/screens/LeavesScreen';
import SettingsScreen from './src/screens/SettingsScreen';
import { colors } from './src/utils/theme';

const Tab   = createBottomTabNavigator();
const Stack = createNativeStackNavigator();

const TAB_ICONS = {
  Home:     '🏠', History: '📅',
  Leaves:   '🌿', Settings: '⚙️',
};

function TabIcon({ name, focused }) {
  return (
    <View style={{ alignItems: 'center' }}>
      <View style={{ opacity: focused ? 1 : 0.5 }}>
        {/* Simple text icons — replace with react-native-vector-icons for production */}
        <View style={{
          width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center',
          backgroundColor: focused ? 'rgba(6,182,212,0.15)' : 'transparent',
        }}>
          <View style={{ fontSize: 20 }} />
        </View>
      </View>
    </View>
  );
}

function MainTabs() {
  return (
    <Tab.Navigator
      screenOptions={({ route }) => ({
        tabBarIcon: ({ focused }) => <TabIcon name={route.name} focused={focused} />,
        tabBarLabel: route.name,
        tabBarActiveTintColor:   colors.cyan,
        tabBarInactiveTintColor: colors.muted,
        tabBarStyle: {
          backgroundColor: 'rgba(5,9,26,0.98)',
          borderTopColor:  colors.border,
          borderTopWidth:  1,
          height:          60,
          paddingBottom:   8,
          paddingTop:      6,
        },
        tabBarLabelStyle: { fontSize: 11, fontWeight: '600' },
        headerStyle:      { backgroundColor: colors.bg, borderBottomColor: colors.border, borderBottomWidth: 1 },
        headerTintColor:  colors.text,
        headerTitleStyle: { fontWeight: '700', fontSize: 17 },
      })}
    >
      <Tab.Screen name="Home"     component={DashboardScreen} options={{ title: 'Dashboard', tabBarIcon: ({ focused }) => <TabEmoji emoji="🏠" focused={focused} /> }} />
      <Tab.Screen name="History"  component={HistoryScreen}   options={{ tabBarIcon: ({ focused }) => <TabEmoji emoji="📅" focused={focused} /> }} />
      <Tab.Screen name="Leaves"   component={LeavesScreen}    options={{ title: 'Leaves & Earnings', tabBarIcon: ({ focused }) => <TabEmoji emoji="🌿" focused={focused} /> }} />
      <Tab.Screen name="Settings" component={SettingsScreen}  options={{ tabBarIcon: ({ focused }) => <TabEmoji emoji="⚙️" focused={focused} /> }} />
    </Tab.Navigator>
  );
}

function TabEmoji({ emoji, focused }) {
  const { Text } = require('react-native');
  return <Text style={{ fontSize: 22, opacity: focused ? 1 : 0.5 }}>{emoji}</Text>;
}

function RootNavigator() {
  const { user, loading } = useAuth();

  if (loading) {
    const { ActivityIndicator } = require('react-native');
    return (
      <View style={{ flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' }}>
        <ActivityIndicator color={colors.cyan} size="large" />
      </View>
    );
  }

  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      {user ? (
        <Stack.Screen name="Main" component={MainTabs} />
      ) : (
        <Stack.Screen name="Login" component={LoginScreen} />
      )}
    </Stack.Navigator>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AuthProvider>
        <NavigationContainer>
          <StatusBar barStyle="light-content" backgroundColor={colors.bg} />
          <RootNavigator />
        </NavigationContainer>
      </AuthProvider>
    </SafeAreaProvider>
  );
}
