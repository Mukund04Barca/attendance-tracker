import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TextInput,
  TouchableOpacity, Alert, RefreshControl, ActivityIndicator,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getMonthRecords, calcEarnings } from '../services/api';
import { colors, radius } from '../utils/theme';

const LEAVE_DEFAULTS = {
  casual:      { label: 'Casual Leave',    entitled: 13.5, color: colors.cyan    },
  earned:      { label: 'Earned Leave',    entitled: 0,    color: colors.emerald },
  sick:        { label: 'Sick Leave',      entitled: 5,    color: colors.amber   },
  paternity:   { label: 'Paternity Leave', entitled: 6,    color: colors.purple  },
  loss_of_pay: { label: 'Loss of Pay',     entitled: 0,    color: colors.danger  },
  comp_off:    { label: 'Comp-Off',        entitled: 0,    color: colors.amber   },
};

const STORAGE_KEY_BALANCES = 'leaveBalances';
const STORAGE_KEY_CONFIG   = 'earningsConfig';

export default function LeavesScreen() {
  const now = new Date();
  const [balances,    setBalances]    = useState({});
  const [config,      setConfig]      = useState({ dailyRate: 250, satRate: 250, satMode: 'pay' });
  const [earnings,    setEarnings]    = useState(null);
  const [editType,    setEditType]    = useState(null); // which leave is being edited
  const [editVals,    setEditVals]    = useState({});
  const [loading,     setLoading]     = useState(true);
  const [refreshing,  setRefreshing]  = useState(false);

  const load = useCallback(async () => {
    try {
      // Load stored balances
      const stored = await AsyncStorage.getItem(STORAGE_KEY_BALANCES);
      if (stored) {
        setBalances(JSON.parse(stored));
      } else {
        // Init defaults
        const def = {};
        Object.entries(LEAVE_DEFAULTS).forEach(([k, v]) => {
          def[k] = { entitled: v.entitled, used: 0, carried: 0 };
        });
        setBalances(def);
        await AsyncStorage.setItem(STORAGE_KEY_BALANCES, JSON.stringify(def));
      }
      // Load earnings config
      const storedCfg = await AsyncStorage.getItem(STORAGE_KEY_CONFIG);
      if (storedCfg) setConfig(JSON.parse(storedCfg));
      // Load month records for earnings calculation
      const records = await getMonthRecords(now.getFullYear(), now.getMonth() + 1);
      const cfg = storedCfg ? JSON.parse(storedCfg) : config;
      setEarnings(calcEarnings(Array.isArray(records) ? records : [], cfg));
    } catch (e) { console.error(e); }
  }, []);

  useEffect(() => {
    (async () => { setLoading(true); await load(); setLoading(false); })();
  }, [load]);

  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const openEdit = (type) => {
    const b = balances[type] || { entitled: LEAVE_DEFAULTS[type].entitled, used: 0, carried: 0 };
    setEditVals({ entitled: String(b.entitled), used: String(b.used), carried: String(b.carried) });
    setEditType(type);
  };

  const saveEdit = async () => {
    const entitled = parseFloat(editVals.entitled) || 0;
    const used     = parseFloat(editVals.used)     || 0;
    const carried  = parseFloat(editVals.carried)  || 0;
    if (entitled < 0 || used < 0 || carried < 0) {
      Alert.alert('Error', 'Values cannot be negative.'); return;
    }
    const updated = { ...balances, [editType]: { entitled, used, carried } };
    setBalances(updated);
    await AsyncStorage.setItem(STORAGE_KEY_BALANCES, JSON.stringify(updated));
    setEditType(null);
  };

  const resetLeave = async (type) => {
    Alert.alert('Reset', `Reset ${LEAVE_DEFAULTS[type].label} to default?`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Reset', style: 'destructive', onPress: async () => {
        const updated = { ...balances, [type]: { entitled: LEAVE_DEFAULTS[type].entitled, used: 0, carried: 0 } };
        setBalances(updated);
        await AsyncStorage.setItem(STORAGE_KEY_BALANCES, JSON.stringify(updated));
      }},
    ]);
  };

  const saveConfig = async () => {
    const daily = parseFloat(config.dailyRate) || 250;
    const sat   = parseFloat(config.satRate)   || 250;
    const cfg   = { ...config, dailyRate: daily, satRate: sat };
    setConfig(cfg);
    await AsyncStorage.setItem(STORAGE_KEY_CONFIG, JSON.stringify(cfg));
    // Recalculate earnings
    const records = await getMonthRecords(now.getFullYear(), now.getMonth() + 1);
    setEarnings(calcEarnings(Array.isArray(records) ? records : [], cfg));
    Alert.alert('Saved', 'Earnings configuration saved.');
  };

  const available = (type) => {
    const b = balances[type] || { entitled: LEAVE_DEFAULTS[type].entitled, used: 0, carried: 0 };
    return Math.round((b.entitled + b.carried - b.used) * 100) / 100;
  };

  if (loading) return <View style={s.centered}><ActivityIndicator color={colors.cyan} /></View>;

  return (
    <ScrollView
      style={s.root}
      contentContainerStyle={s.content}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.cyan} />}
    >
      {/* ── Leave Balances ── */}
      <Text style={s.sectionTitle}>Leave Balances</Text>
      {Object.entries(LEAVE_DEFAULTS).map(([type, meta]) => {
        const avail = available(type);
        const b     = balances[type] || { entitled: meta.entitled, used: 0, carried: 0 };
        const isEditing = editType === type;

        return (
          <View key={type} style={s.leaveCard}>
            <View style={s.leaveRow}>
              <View style={s.leaveLeft}>
                <Text style={s.leaveType}>{meta.label}</Text>
                <Text style={s.leaveDetail}>{b.used} used · {b.entitled} entitled{b.carried > 0 ? ` + ${b.carried} carried` : ''}</Text>
              </View>
              <View style={s.leaveRight}>
                <Text style={[s.leaveAvail, { color: avail > 0 ? meta.color : avail < 0 ? colors.danger : colors.muted }]}>
                  {avail}
                </Text>
                <TouchableOpacity style={s.editLeaveBtn} onPress={() => isEditing ? setEditType(null) : openEdit(type)}>
                  <Text style={s.editLeaveBtnText}>{isEditing ? 'Close' : '✏️'}</Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Progress bar */}
            {b.entitled > 0 && (
              <View style={s.progBar}>
                <View style={[s.progFill, { width: `${Math.min((b.used / b.entitled) * 100, 100)}%`, backgroundColor: meta.color }]} />
              </View>
            )}

            {/* Inline edit */}
            {isEditing && (
              <View style={s.editPanel}>
                <View style={s.editGrid}>
                  {[['Entitled', 'entitled'], ['Used', 'used'], ['Carry-over', 'carried']].map(([label, key]) => (
                    <View key={key} style={s.editField}>
                      <Text style={s.editLabel}>{label}</Text>
                      <TextInput
                        style={s.editInput}
                        value={editVals[key]}
                        onChangeText={v => setEditVals(prev => ({ ...prev, [key]: v }))}
                        keyboardType="decimal-pad"
                        placeholder="0"
                        placeholderTextColor={colors.dim}
                      />
                    </View>
                  ))}
                </View>
                <Text style={s.editPreview}>
                  Available = {(
                    (parseFloat(editVals.entitled) || 0) +
                    (parseFloat(editVals.carried)  || 0) -
                    (parseFloat(editVals.used)     || 0)
                  ).toFixed(1)}
                </Text>
                <View style={s.editActions}>
                  <TouchableOpacity style={s.saveLeaveBtn} onPress={saveEdit}>
                    <Text style={s.saveLeaveBtnText}>Save</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={s.resetLeaveBtn} onPress={() => resetLeave(type)}>
                    <Text style={s.resetLeaveBtnText}>Reset Default</Text>
                  </TouchableOpacity>
                </View>
              </View>
            )}
          </View>
        );
      })}

      {/* ── Earnings ── */}
      <Text style={[s.sectionTitle, { marginTop: 24 }]}>
        Earnings — {now.toLocaleDateString('en-IN', { month: 'long', year: 'numeric' })}
      </Text>
      {earnings && (
        <View style={s.card}>
          {[
            ['Weekdays worked', `${earnings.weekdays} × ₹${config.dailyRate}`, colors.text],
            ['Weekday earnings', `₹${earnings.wEarn}`, colors.emerald],
            earnings.saturdays > 0 ? ['Saturday', config.satMode === 'pay' ? `${earnings.saturdays} × ₹${config.satRate} = ₹${earnings.sEarn}` : `${earnings.saturdays} day(s) → Comp-Off`, colors.amber] : null,
            earnings.lop > 0 ? ['Loss of Pay', `- ₹${earnings.lopDed}`, colors.danger] : null,
          ].filter(Boolean).map(([label, val, color]) => (
            <View key={label} style={s.earnRow}>
              <Text style={s.earnLabel}>{label}</Text>
              <Text style={[s.earnVal, { color }]}>{val}</Text>
            </View>
          ))}
          <View style={[s.earnRow, s.earnTotalRow]}>
            <Text style={s.earnTotalLabel}>Total Earnings</Text>
            <Text style={s.earnTotalVal}>₹{earnings.total}</Text>
          </View>
        </View>
      )}

      {/* ── Earnings Config ── */}
      <Text style={[s.sectionTitle, { marginTop: 24 }]}>Configure Earnings</Text>
      <View style={s.card}>
        <Text style={s.cfgLabel}>Daily Rate (₹ / weekday)</Text>
        <TextInput
          style={s.cfgInput}
          value={String(config.dailyRate)}
          onChangeText={v => setConfig(c => ({ ...c, dailyRate: v }))}
          keyboardType="decimal-pad"
          placeholder="250"
          placeholderTextColor={colors.dim}
        />

        <Text style={[s.cfgLabel, { marginTop: 14 }]}>Saturday Mode</Text>
        <View style={s.pillRow}>
          {[['pay', 'Pay'], ['comp_off', 'Comp-Off']].map(([val, label]) => (
            <TouchableOpacity
              key={val}
              style={[s.pill, config.satMode === val && s.pillActive]}
              onPress={() => setConfig(c => ({ ...c, satMode: val }))}
            >
              <Text style={[s.pillText, config.satMode === val && s.pillTextActive]}>{label}</Text>
            </TouchableOpacity>
          ))}
        </View>

        {config.satMode === 'pay' && (
          <>
            <Text style={[s.cfgLabel, { marginTop: 14 }]}>Saturday Rate (₹)</Text>
            <TextInput
              style={s.cfgInput}
              value={String(config.satRate)}
              onChangeText={v => setConfig(c => ({ ...c, satRate: v }))}
              keyboardType="decimal-pad"
              placeholder="250"
              placeholderTextColor={colors.dim}
            />
          </>
        )}

        <TouchableOpacity style={s.saveConfigBtn} onPress={saveConfig}>
          <Text style={s.saveConfigText}>Save Configuration</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  root:        { flex: 1, backgroundColor: colors.bg },
  content:     { padding: 16, paddingBottom: 40 },
  centered:    { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center' },
  sectionTitle:{ fontSize: 11, fontWeight: '600', color: colors.muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 12 },

  leaveCard:   { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: 14, marginBottom: 10 },
  leaveRow:    { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  leaveLeft:   { flex: 1 },
  leaveType:   { fontSize: 14, fontWeight: '600', color: colors.text },
  leaveDetail: { fontSize: 11, color: colors.muted, marginTop: 2 },
  leaveRight:  { flexDirection: 'row', alignItems: 'center', gap: 10 },
  leaveAvail:  { fontSize: 26, fontWeight: '800', fontVariant: ['tabular-nums'] },
  editLeaveBtn:{ paddingHorizontal: 8, paddingVertical: 4, backgroundColor: 'rgba(6,182,212,0.1)', borderWidth: 1, borderColor: 'rgba(6,182,212,0.2)', borderRadius: 6 },
  editLeaveBtnText: { fontSize: 12, color: colors.cyan, fontWeight: '600' },

  progBar:     { height: 3, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden', marginTop: 10 },
  progFill:    { height: '100%', borderRadius: 2 },

  editPanel:   { marginTop: 14, paddingTop: 14, borderTopWidth: 1, borderColor: 'rgba(255,255,255,0.06)' },
  editGrid:    { flexDirection: 'row', gap: 10 },
  editField:   { flex: 1 },
  editLabel:   { fontSize: 10, color: colors.cyan, fontWeight: '600', letterSpacing: 0.8, marginBottom: 5, textTransform: 'uppercase' },
  editInput:   { backgroundColor: 'rgba(255,255,255,0.07)', borderWidth: 1, borderColor: 'rgba(6,182,212,0.25)', borderRadius: radius.sm, color: colors.text, padding: 10, fontSize: 14, textAlign: 'center' },
  editPreview: { textAlign: 'center', fontSize: 12, color: colors.muted, marginTop: 8, marginBottom: 10 },
  editActions: { flexDirection: 'row', gap: 10 },
  saveLeaveBtn:  { flex: 1, backgroundColor: colors.cyan, borderRadius: radius.sm, padding: 10, alignItems: 'center' },
  saveLeaveBtnText: { fontSize: 13, fontWeight: '700', color: '#020617' },
  resetLeaveBtn: { flex: 1, backgroundColor: 'rgba(244,63,94,0.1)', borderWidth: 1, borderColor: 'rgba(244,63,94,0.2)', borderRadius: radius.sm, padding: 10, alignItems: 'center' },
  resetLeaveBtnText: { fontSize: 13, fontWeight: '600', color: colors.danger },

  card:        { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: 16, marginBottom: 10 },
  earnRow:     { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingVertical: 9, borderBottomWidth: 1, borderColor: 'rgba(255,255,255,0.04)' },
  earnLabel:   { fontSize: 13, color: colors.muted },
  earnVal:     { fontSize: 13, fontWeight: '700', fontVariant: ['tabular-nums'] },
  earnTotalRow:{ borderBottomWidth: 0, paddingTop: 14 },
  earnTotalLabel:{ fontSize: 15, fontWeight: '700', color: colors.text },
  earnTotalVal:  { fontSize: 22, fontWeight: '800', color: colors.emerald, fontVariant: ['tabular-nums'] },

  cfgLabel:    { fontSize: 11, color: colors.cyan, fontWeight: '600', letterSpacing: 0.8, marginBottom: 6, textTransform: 'uppercase' },
  cfgInput:    { backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, color: colors.text, padding: 11, fontSize: 15 },
  pillRow:     { flexDirection: 'row', gap: 8 },
  pill:        { paddingHorizontal: 18, paddingVertical: 8, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.05)', borderWidth: 1, borderColor: colors.border },
  pillActive:  { backgroundColor: colors.cyan, borderColor: colors.cyan },
  pillText:    { fontSize: 13, color: colors.muted, fontWeight: '600' },
  pillTextActive:{ color: '#020617' },
  saveConfigBtn:{ marginTop: 18, backgroundColor: colors.cyan, borderRadius: radius.md, padding: 13, alignItems: 'center' },
  saveConfigText:{ fontSize: 15, fontWeight: '700', color: '#020617' },
});
