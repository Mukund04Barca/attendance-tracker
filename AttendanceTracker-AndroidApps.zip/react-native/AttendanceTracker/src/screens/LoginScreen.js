import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ScrollView, ActivityIndicator, Alert,
} from 'react-native';
import { useAuth } from '../context/AuthContext';
import { colors, radius } from '../utils/theme';

export default function LoginScreen() {
  const { login } = useAuth();
  const [serverUrl, setServerUrl] = useState('http://192.168.1.100:8000');
  const [username,  setUsername]  = useState('');
  const [password,  setPassword]  = useState('');
  const [loading,   setLoading]   = useState(false);

  const handleLogin = async () => {
    if (!serverUrl || !username || !password) {
      Alert.alert('Error', 'All fields are required.');
      return;
    }
    setLoading(true);
    try {
      await login(serverUrl.trim(), username.trim(), password);
    } catch (e) {
      Alert.alert('Login Failed', e.response?.data?.detail || 'Invalid credentials or server unreachable.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView style={s.root} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={s.scroll} keyboardShouldPersistTaps="handled">
        {/* Logo */}
        <View style={s.logoWrap}>
          <Text style={s.logoEmoji}>⏱</Text>
          <Text style={s.logoTitle}>Attendance Tracker</Text>
          <Text style={s.logoSub}>Track your time, effortlessly</Text>
        </View>

        {/* Card */}
        <View style={s.card}>
          <Text style={s.fieldLabel}>SERVER URL</Text>
          <TextInput
            style={s.input}
            value={serverUrl}
            onChangeText={setServerUrl}
            placeholder="http://192.168.1.x:8000"
            placeholderTextColor={colors.dim}
            autoCapitalize="none"
            keyboardType="url"
          />

          <Text style={[s.fieldLabel, { marginTop: 14 }]}>USERNAME</Text>
          <TextInput
            style={s.input}
            value={username}
            onChangeText={setUsername}
            placeholder="username"
            placeholderTextColor={colors.dim}
            autoCapitalize="none"
          />

          <Text style={[s.fieldLabel, { marginTop: 14 }]}>PASSWORD</Text>
          <TextInput
            style={s.input}
            value={password}
            onChangeText={setPassword}
            placeholder="••••••••"
            placeholderTextColor={colors.dim}
            secureTextEntry
          />

          <TouchableOpacity style={s.btn} onPress={handleLogin} disabled={loading} activeOpacity={0.85}>
            {loading
              ? <ActivityIndicator color="#020617" />
              : <Text style={s.btnText}>Sign In →</Text>
            }
          </TouchableOpacity>
        </View>

        <Text style={s.hint}>Make sure your phone and server are on the same network</Text>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const s = StyleSheet.create({
  root:      { flex: 1, backgroundColor: colors.bg },
  scroll:    { flexGrow: 1, justifyContent: 'center', padding: 24 },
  logoWrap:  { alignItems: 'center', marginBottom: 40 },
  logoEmoji: { fontSize: 48, marginBottom: 10 },
  logoTitle: { fontSize: 28, fontWeight: '800', color: colors.cyan, letterSpacing: -0.5 },
  logoSub:   { fontSize: 14, color: colors.muted, marginTop: 6 },
  card:      { backgroundColor: colors.card, borderRadius: radius.xl, padding: 24, borderWidth: 1, borderColor: colors.border },
  fieldLabel:{ fontSize: 11, fontWeight: '600', color: colors.cyan, letterSpacing: 1, marginBottom: 6, textTransform: 'uppercase' },
  input:     { backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: colors.border, borderRadius: radius.sm, color: colors.text, padding: 12, fontSize: 15 },
  btn:       { marginTop: 20, backgroundColor: colors.cyan, borderRadius: radius.md, padding: 15, alignItems: 'center' },
  btnText:   { fontSize: 16, fontWeight: '700', color: '#020617' },
  hint:      { textAlign: 'center', color: colors.dim, fontSize: 12, marginTop: 20 },
});
