import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, ScrollView, TouchableOpacity,
  Alert, TextInput,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../context/AuthContext';
import { getStoredServer } from '../services/api';
import { colors, radius } from '../utils/theme';

export default function SettingsScreen() {
  const { user, logout } = useAuth();
  const [server, setServer] = useState('');
  const [target, setTarget] = useState('9');
  const [editTarget, setEditTarget] = useState(false);

  useEffect(() => {
    (async () => {
      const s = await getStoredServer();
      setServer(s || '');
      const t = await AsyncStorage.getItem('dailyTarget');
      if (t) setTarget(t);
    })();
  }, []);

  const saveTarget = async () => {
    const val = parseFloat(target);
    if (isNaN(val) || val < 1 || val > 24) {
      Alert.alert('Error', 'Target must be between 1 and 24 hours.');
      return;
    }
    await AsyncStorage.setItem('dailyTarget', String(val));
    setEditTarget(false);
    Alert.alert('Saved', `Daily target set to ${val}h`);
  };

  const handleLogout = () => {
    Alert.alert('Sign Out', 'Are you sure you want to sign out?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Sign Out', style: 'destructive', onPress: logout },
    ]);
  };

  const Row = ({ label, sub, right, onPress }) => (
    <TouchableOpacity style={s.row} onPress={onPress} disabled={!onPress} activeOpacity={0.7}>
      <View style={{ flex: 1 }}>
        <Text style={s.rowLabel}>{label}</Text>
        {sub ? <Text style={s.rowSub}>{sub}</Text> : null}
      </View>
      {right}
    </TouchableOpacity>
  );

  return (
    <ScrollView style={s.root} contentContainerStyle={s.content}>
      {/* Account */}
      <Text style={s.sectionTitle}>Account</Text>
      <View style={s.card}>
        <Row label={user || '—'} sub="Logged in as" right={
          <View style={s.badge}><Text style={s.badgeText}>Active</Text></View>
        } />
        <View style={s.divider} />
        <Row label="Server" sub={server || '—'} />
        <View style={s.divider} />
        <TouchableOpacity style={s.logoutBtn} onPress={handleLogout} activeOpacity={0.8}>
          <Text style={s.logoutText}>Sign Out</Text>
        </TouchableOpacity>
      </View>

      {/* Work Settings */}
      <Text style={[s.sectionTitle, { marginTop: 24 }]}>Work Settings</Text>
      <View style={s.card}>
        <Row
          label="Daily Target"
          sub={`${target}h per weekday`}
          right={
            <TouchableOpacity style={s.editBtn} onPress={() => setEditTarget(!editTarget)}>
              <Text style={s.editBtnText}>{editTarget ? 'Cancel' : 'Edit'}</Text>
            </TouchableOpacity>
          }
        />
        {editTarget && (
          <View style={s.targetEdit}>
            <TextInput
              style={s.targetInput}
              value={target}
              onChangeText={setTarget}
              keyboardType="decimal-pad"
              placeholder="9"
              placeholderTextColor={colors.dim}
            />
            <TouchableOpacity style={s.targetSaveBtn} onPress={saveTarget}>
              <Text style={s.targetSaveText}>Save</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>

      {/* About */}
      <Text style={[s.sectionTitle, { marginTop: 24 }]}>About</Text>
      <View style={s.card}>
        <Row label="Attendance Tracker" sub="Version 1.0.0" />
        <View style={s.divider} />
        <Row label="Server" sub={server} />
      </View>

      <Text style={s.footer}>Built for attendacetracker.duckdns.org</Text>
    </ScrollView>
  );
}

const s = StyleSheet.create({
  root:        { flex: 1, backgroundColor: colors.bg },
  content:     { padding: 16, paddingBottom: 40 },
  sectionTitle:{ fontSize: 11, fontWeight: '600', color: colors.muted, textTransform: 'uppercase', letterSpacing: 1, marginBottom: 10 },
  card:        { backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, overflow: 'hidden' },
  row:         { flexDirection: 'row', alignItems: 'center', padding: 16 },
  rowLabel:    { fontSize: 14, fontWeight: '600', color: colors.text },
  rowSub:      { fontSize: 12, color: colors.muted, marginTop: 2 },
  divider:     { height: 1, backgroundColor: 'rgba(255,255,255,0.04)', marginLeft: 16 },
  badge:       { backgroundColor: 'rgba(16,185,129,0.12)', borderWidth: 1, borderColor: 'rgba(16,185,129,0.2)', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 },
  badgeText:   { fontSize: 11, color: colors.emerald, fontWeight: '700' },
  logoutBtn:   { margin: 12, backgroundColor: 'rgba(244,63,94,0.1)', borderWidth: 1, borderColor: 'rgba(244,63,94,0.2)', borderRadius: radius.sm, padding: 12, alignItems: 'center' },
  logoutText:  { fontSize: 14, color: colors.danger, fontWeight: '700' },
  editBtn:     { paddingHorizontal: 12, paddingVertical: 6, backgroundColor: 'rgba(6,182,212,0.1)', borderWidth: 1, borderColor: 'rgba(6,182,212,0.2)', borderRadius: 8 },
  editBtnText: { fontSize: 12, color: colors.cyan, fontWeight: '600' },
  targetEdit:  { flexDirection: 'row', gap: 10, padding: 12, paddingTop: 0 },
  targetInput: { flex: 1, backgroundColor: 'rgba(255,255,255,0.06)', borderWidth: 1, borderColor: 'rgba(6,182,212,0.25)', borderRadius: radius.sm, color: colors.text, padding: 10, fontSize: 15 },
  targetSaveBtn:{ backgroundColor: colors.cyan, borderRadius: radius.sm, paddingHorizontal: 18, alignItems: 'center', justifyContent: 'center' },
  targetSaveText:{ fontSize: 13, fontWeight: '700', color: '#020617' },
  footer:      { textAlign: 'center', color: colors.dim, fontSize: 12, marginTop: 30 },
});
