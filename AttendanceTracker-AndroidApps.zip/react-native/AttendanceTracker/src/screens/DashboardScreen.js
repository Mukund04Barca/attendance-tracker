import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ScrollView,
  RefreshControl, ActivityIndicator, Alert, Modal, TextInput,
} from 'react-native';
import {
  getTodayRecord, checkIn, checkOut, setManualTime,
  getWeekRecords, secToHHMM, hoursToHHMM,
} from '../services/api';
import { useAuth } from '../context/AuthContext';
import { colors, radius } from '../utils/theme';

const DAILY_TARGET = 9; // hours

export default function DashboardScreen() {
  const { user } = useAuth();
  const [record,      setRecord]      = useState(null);
  const [loading,     setLoading]     = useState(true);
  const [refreshing,  setRefreshing]  = useState(false);
  const [actionLoad,  setActionLoad]  = useState(false);
  const [elapsed,     setElapsed]     = useState(0);   // seconds
  const [weekData,    setWeekData]    = useState({ total: 0, days: 0, recorded: 0 });
  const [modalVisible,setModal]       = useState(false);
  const [manualIn,    setManualIn]    = useState('');
  const [manualOut,   setManualOut]   = useState('');
  const timerRef = useRef(null);

  // ── Load data ──────────────────────────────────────
  const load = useCallback(async () => {
    try {
      const [rec, week] = await Promise.all([getTodayRecord(), getWeekRecords()]);
      setRecord(rec);
      // Week stats
      const completed = week.filter(r => r.check_in && r.check_out);
      const total = completed.reduce((s, r) => {
        return s + Math.max((new Date(r.check_out) - new Date(r.check_in)) / 3600000, 0);
      }, 0);
      setWeekData({ total, days: completed.length, recorded: week.length });
      // Start timer if checked in but not out
      if (rec?.check_in && !rec?.check_out) {
        startTimer(new Date(rec.check_in));
      } else {
        stopTimer();
        if (rec?.check_in && rec?.check_out) {
          const dur = (new Date(rec.check_out) - new Date(rec.check_in)) / 1000;
          setElapsed(dur);
        }
      }
    } catch (e) {
      Alert.alert('Error', 'Could not load data. Check your connection.');
    }
  }, []);

  useEffect(() => {
    (async () => { setLoading(true); await load(); setLoading(false); })();
    return () => stopTimer();
  }, [load]);

  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  // ── Timer ──────────────────────────────────────────
  const startTimer = (checkInTime) => {
    stopTimer();
    const tick = () => {
      const secs = (Date.now() - checkInTime.getTime()) / 1000;
      setElapsed(Math.max(secs, 0));
    };
    tick();
    timerRef.current = setInterval(tick, 30000); // update every 30s
  };

  const stopTimer = () => {
    if (timerRef.current) { clearInterval(timerRef.current); timerRef.current = null; }
  };

  // ── Actions ────────────────────────────────────────
  const handleCheckin = async () => {
    setActionLoad(true);
    try {
      const updated = await checkIn(record?.id || null);
      setRecord(updated);
      startTimer(new Date(updated.check_in));
    } catch (e) {
      Alert.alert('Error', e.response?.data?.detail || 'Check-in failed.');
    }
    setActionLoad(false);
  };

  const handleCheckout = async () => {
    if (!record?.id) return;
    setActionLoad(true);
    try {
      const updated = await checkOut(record.id);
      setRecord(updated);
      stopTimer();
      const dur = (new Date(updated.check_out) - new Date(updated.check_in)) / 1000;
      setElapsed(dur);
      await load(); // refresh week stats
    } catch (e) {
      Alert.alert('Error', e.response?.data?.detail || 'Check-out failed.');
    }
    setActionLoad(false);
  };

  const handleManualSave = async () => {
    if (manualIn && manualOut) {
      const [h1, m1] = manualIn.split(':').map(Number);
      const [h2, m2] = manualOut.split(':').map(Number);
      if ((h2 * 60 + m2) <= (h1 * 60 + m1)) {
        Alert.alert('Error', 'Check-out must be after check-in.');
        return;
      }
    }
    setActionLoad(true);
    try {
      const updated = await setManualTime(record?.id, manualIn, manualOut);
      setRecord(updated);
      setModal(false);
      await load();
    } catch (e) {
      Alert.alert('Error', 'Failed to save time.');
    }
    setActionLoad(false);
  };

  // ── Computed values ────────────────────────────────
  const isCheckedIn  = !!record?.check_in;
  const isCheckedOut = !!record?.check_out;
  const remaining    = Math.max(DAILY_TARGET * 3600 - elapsed, 0);
  const expectedOut  = isCheckedIn && !isCheckedOut
    ? new Date(new Date(record.check_in).getTime() + DAILY_TARGET * 3600000)
        .toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false })
    : null;
  const weekTarget   = 5 * DAILY_TARGET;
  const weekPct      = Math.min(Math.round((weekData.total / weekTarget) * 100), 100);
  const dayPct       = weekData.recorded
    ? Math.min(Math.round((weekData.days / weekData.recorded) * 100), 100) : 0;

  const greeting = () => {
    const h = new Date().getHours();
    return h < 12 ? 'morning' : h < 17 ? 'afternoon' : 'evening';
  };

  // ── Duration preview in manual modal ──────────────
  const durPreview = () => {
    if (!manualIn || !manualOut) return '';
    const [h1, m1] = manualIn.split(':').map(Number);
    const [h2, m2] = manualOut.split(':').map(Number);
    const diff = (h2 * 60 + m2) - (h1 * 60 + m1);
    if (diff <= 0) return '⚠ Invalid';
    return `${Math.floor(diff / 60)}h ${diff % 60}m`;
  };

  if (loading) {
    return (
      <View style={s.centered}>
        <ActivityIndicator size="large" color={colors.cyan} />
        <Text style={s.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <View style={s.root}>
      <ScrollView
        style={s.scroll}
        contentContainerStyle={s.content}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.cyan} />}
      >
        {/* Header */}
        <View style={s.header}>
          <View>
            <Text style={s.greeting}>Good {greeting()} 👋</Text>
            <Text style={s.date}>{new Date().toLocaleDateString('en-IN', { weekday: 'long', day: 'numeric', month: 'long' })}</Text>
          </View>
          <View style={s.userBadge}>
            <Text style={s.userText}>{user}</Text>
          </View>
        </View>

        {/* Hero Card */}
        <View style={s.heroCard}>
          <Text style={s.heroTime}>
            {isCheckedIn ? secToHHMM(elapsed) : '--:--'}
          </Text>
          <Text style={s.heroLabel}>
            {isCheckedOut ? 'SESSION COMPLETE' : isCheckedIn ? 'ELAPSED' : 'SESSION DURATION'}
          </Text>

          {/* Status pill */}
          <View style={[s.statusPill, isCheckedIn && !isCheckedOut ? s.statusActive : s.statusInactive]}>
            <View style={[s.statusDot, isCheckedIn && !isCheckedOut ? s.dotActive : s.dotInactive]} />
            <Text style={[s.statusText, isCheckedIn && !isCheckedOut ? s.statusTextActive : s.statusTextInactive]}>
              {isCheckedOut ? 'Session Complete' : isCheckedIn ? 'Session Active' : 'Not Started'}
            </Text>
          </View>

          {/* Action button */}
          {actionLoad ? (
            <ActivityIndicator color={isCheckedIn ? colors.danger : colors.cyan} style={{ marginTop: 20 }} />
          ) : !isCheckedIn ? (
            <TouchableOpacity style={[s.actionBtn, s.btnCheckin]} onPress={handleCheckin} activeOpacity={0.85}>
              <Text style={s.actionBtnText}>▶  Start Session</Text>
            </TouchableOpacity>
          ) : !isCheckedOut ? (
            <TouchableOpacity style={[s.actionBtn, s.btnCheckout]} onPress={handleCheckout} activeOpacity={0.85}>
              <Text style={[s.actionBtnText, { color: '#fff' }]}>⏹  End Session</Text>
            </TouchableOpacity>
          ) : null}

          {/* Edit time button */}
          {isCheckedIn && (
            <TouchableOpacity style={s.editBtn} onPress={() => {
              if (record?.check_in) {
                const ci = new Date(record.check_in);
                setManualIn(`${String(ci.getHours()).padStart(2,'0')}:${String(ci.getMinutes()).padStart(2,'0')}`);
              }
              if (record?.check_out) {
                const co = new Date(record.check_out);
                setManualOut(`${String(co.getHours()).padStart(2,'0')}:${String(co.getMinutes()).padStart(2,'0')}`);
              }
              setModal(true);
            }}>
              <Text style={s.editBtnText}>✏️  Edit Time</Text>
            </TouchableOpacity>
          )}

          {/* Remaining */}
          {isCheckedIn && !isCheckedOut && (
            <View style={s.remainRow}>
              <View>
                <Text style={s.remainLabel}>Remaining</Text>
                <Text style={s.remainVal}>{secToHHMM(remaining)}</Text>
              </View>
              <View style={{ alignItems: 'flex-end' }}>
                <Text style={s.remainLabel}>Suggested checkout</Text>
                <Text style={[s.remainVal, { color: colors.cyan }]}>{expectedOut}</Text>
              </View>
            </View>
          )}
        </View>

        {/* Week Stats */}
        <View style={s.statsRow}>
          <View style={s.statCard}>
            <Text style={[s.statVal, { color: colors.cyan }]}>{hoursToHHMM(weekData.total)}</Text>
            <Text style={s.statLbl}>Weekly Hours</Text>
            <Text style={s.statSub}>Target: {weekTarget}h</Text>
            <View style={s.progBar}><View style={[s.progFill, { width: `${weekPct}%` }]} /></View>
          </View>
          <View style={s.statCard}>
            <Text style={[s.statVal, { color: colors.emerald }]}>{weekData.days}/{weekData.recorded}</Text>
            <Text style={s.statLbl}>Days This Week</Text>
            <Text style={s.statSub}>{dayPct}% complete</Text>
            <View style={s.progBar}><View style={[s.progFill, { width: `${dayPct}%`, backgroundColor: colors.emerald }]} /></View>
          </View>
        </View>
      </ScrollView>

      {/* Manual Time Modal */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={s.modalOverlay}>
          <View style={s.modalSheet}>
            <View style={s.modalHandle} />
            <Text style={s.modalTitle}>Edit Today's Time</Text>

            {/* Presets */}
            <View style={s.presetRow}>
              {[['Standard 9–6','09:00','18:00'],['Half Day','09:00','13:00']].map(([label, ci, co]) => (
                <TouchableOpacity key={label} style={s.presetBtn}
                  onPress={() => { setManualIn(ci); setManualOut(co); }}>
                  <Text style={s.presetText}>{label}</Text>
                </TouchableOpacity>
              ))}
              <TouchableOpacity style={s.presetBtn} onPress={() => { setManualIn(''); setManualOut(''); }}>
                <Text style={s.presetText}>Clear</Text>
              </TouchableOpacity>
            </View>

            {/* Inputs */}
            <View style={s.timeRow}>
              <View style={{ flex: 1 }}>
                <Text style={s.fieldLabel}>CHECK-IN</Text>
                <TextInput style={s.timeInput} value={manualIn} onChangeText={setManualIn}
                  placeholder="09:00" placeholderTextColor={colors.dim} keyboardType="numbers-and-punctuation" />
              </View>
              <View style={{ width: 12 }} />
              <View style={{ flex: 1 }}>
                <Text style={s.fieldLabel}>CHECK-OUT</Text>
                <TextInput style={s.timeInput} value={manualOut} onChangeText={setManualOut}
                  placeholder="18:00" placeholderTextColor={colors.dim} keyboardType="numbers-and-punctuation" />
              </View>
            </View>

            {(manualIn && manualOut) && (
              <Text style={[s.durPreview, durPreview().includes('⚠') ? { color: colors.danger } : {}]}>
                Duration: {durPreview()}
              </Text>
            )}

            <TouchableOpacity style={s.modalSaveBtn} onPress={handleManualSave} disabled={actionLoad}>
              {actionLoad ? <ActivityIndicator color="#020617" /> : <Text style={s.modalSaveText}>Save Time</Text>}
            </TouchableOpacity>
            <TouchableOpacity style={s.modalCancelBtn} onPress={() => setModal(false)}>
              <Text style={s.modalCancelText}>Cancel</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const s = StyleSheet.create({
  root:        { flex: 1, backgroundColor: colors.bg },
  scroll:      { flex: 1 },
  content:     { padding: 16, paddingBottom: 30 },
  centered:    { flex: 1, backgroundColor: colors.bg, alignItems: 'center', justifyContent: 'center', gap: 12 },
  loadingText: { color: colors.muted, fontSize: 14 },

  header:      { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  greeting:    { fontSize: 20, fontWeight: '700', color: colors.text },
  date:        { fontSize: 12, color: colors.muted, marginTop: 2 },
  userBadge:   { backgroundColor: 'rgba(6,182,212,0.12)', borderWidth: 1, borderColor: 'rgba(6,182,212,0.2)', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 5 },
  userText:    { color: colors.cyan, fontSize: 12, fontWeight: '700' },

  heroCard:    { backgroundColor: 'rgba(6,182,212,0.06)', borderWidth: 1, borderColor: colors.borderHi, borderRadius: radius.xl, padding: 24, alignItems: 'center', marginBottom: 16 },
  heroTime:    { fontSize: 64, fontWeight: '800', color: colors.cyan, letterSpacing: -2, fontVariant: ['tabular-nums'] },
  heroLabel:   { fontSize: 11, color: colors.muted, fontWeight: '600', letterSpacing: 1, marginTop: 4 },

  statusPill:       { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 12, paddingHorizontal: 14, paddingVertical: 6, borderRadius: 20, borderWidth: 1 },
  statusActive:     { backgroundColor: 'rgba(16,185,129,0.1)', borderColor: 'rgba(16,185,129,0.2)' },
  statusInactive:   { backgroundColor: 'rgba(148,163,184,0.1)', borderColor: 'rgba(148,163,184,0.2)' },
  statusDot:        { width: 7, height: 7, borderRadius: 4 },
  dotActive:        { backgroundColor: colors.emerald },
  dotInactive:      { backgroundColor: colors.muted },
  statusText:       { fontSize: 12, fontWeight: '600' },
  statusTextActive: { color: colors.emerald },
  statusTextInactive:{ color: colors.muted },

  actionBtn:    { width: '100%', padding: 18, borderRadius: radius.lg, alignItems: 'center', marginTop: 18, minHeight: 56 },
  btnCheckin:   { backgroundColor: colors.cyan },
  btnCheckout:  { backgroundColor: colors.danger },
  actionBtnText:{ fontSize: 17, fontWeight: '700', color: '#020617' },

  editBtn:      { marginTop: 10, paddingHorizontal: 18, paddingVertical: 8, borderRadius: radius.md, borderWidth: 1, borderColor: colors.border, backgroundColor: 'rgba(255,255,255,0.04)' },
  editBtnText:  { fontSize: 13, color: colors.muted, fontWeight: '600' },

  remainRow:    { flexDirection: 'row', justifyContent: 'space-between', width: '100%', marginTop: 16, paddingTop: 14, borderTopWidth: 1, borderColor: 'rgba(255,255,255,0.06)' },
  remainLabel:  { fontSize: 11, color: colors.muted },
  remainVal:    { fontSize: 20, fontWeight: '800', color: colors.amber, fontVariant: ['tabular-nums'] },

  statsRow:     { flexDirection: 'row', gap: 12 },
  statCard:     { flex: 1, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: 14 },
  statVal:      { fontSize: 24, fontWeight: '800', fontVariant: ['tabular-nums'] },
  statLbl:      { fontSize: 10, color: colors.muted, textTransform: 'uppercase', letterSpacing: 0.8, marginTop: 2 },
  statSub:      { fontSize: 11, color: colors.dim, marginTop: 4 },
  progBar:      { height: 3, backgroundColor: 'rgba(255,255,255,0.06)', borderRadius: 2, overflow: 'hidden', marginTop: 8 },
  progFill:     { height: '100%', backgroundColor: colors.cyan, borderRadius: 2 },

  // Modal
  modalOverlay:   { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  modalSheet:     { backgroundColor: '#0f172a', borderTopLeftRadius: 20, borderTopRightRadius: 20, borderWidth: 1, borderColor: colors.border, padding: 20, paddingBottom: 34 },
  modalHandle:    { width: 36, height: 4, backgroundColor: colors.border, borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
  modalTitle:     { fontSize: 17, fontWeight: '700', color: colors.text, marginBottom: 16 },
  presetRow:      { flexDirection: 'row', gap: 8, marginBottom: 16, flexWrap: 'wrap' },
  presetBtn:      { paddingHorizontal: 12, paddingVertical: 7, backgroundColor: 'rgba(6,182,212,0.1)', borderWidth: 1, borderColor: 'rgba(6,182,212,0.2)', borderRadius: 20 },
  presetText:     { fontSize: 12, color: colors.cyan, fontWeight: '600' },
  timeRow:        { flexDirection: 'row', marginBottom: 10 },
  fieldLabel:     { fontSize: 11, fontWeight: '600', color: colors.cyan, letterSpacing: 1, marginBottom: 6 },
  timeInput:      { backgroundColor: 'rgba(255,255,255,0.07)', borderWidth: 1, borderColor: 'rgba(6,182,212,0.25)', borderRadius: radius.sm, color: colors.text, padding: 12, fontSize: 16, fontVariant: ['tabular-nums'] },
  durPreview:     { textAlign: 'center', fontSize: 13, color: colors.emerald, fontWeight: '600', marginBottom: 12 },
  modalSaveBtn:   { backgroundColor: colors.cyan, borderRadius: radius.md, padding: 14, alignItems: 'center', marginTop: 6 },
  modalSaveText:  { fontSize: 15, fontWeight: '700', color: '#020617' },
  modalCancelBtn: { padding: 12, alignItems: 'center', marginTop: 8 },
  modalCancelText:{ fontSize: 14, color: colors.muted },
});
