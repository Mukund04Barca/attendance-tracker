import React, { useState, useEffect, useCallback } from 'react';
import {
  View, Text, StyleSheet, FlatList, RefreshControl,
  ActivityIndicator, TouchableOpacity,
} from 'react-native';
import { getMonthRecords, hoursToHHMM } from '../services/api';
import { colors, radius } from '../utils/theme';

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];

export default function HistoryScreen() {
  const now = new Date();
  const [year,      setYear]      = useState(now.getFullYear());
  const [month,     setMonth]     = useState(now.getMonth() + 1);
  const [records,   setRecords]   = useState([]);
  const [loading,   setLoading]   = useState(true);
  const [refreshing,setRefreshing]= useState(false);

  const load = useCallback(async () => {
    try {
      const data = await getMonthRecords(year, month);
      setRecords(Array.isArray(data) ? data : []);
    } catch { setRecords([]); }
  }, [year, month]);

  useEffect(() => {
    (async () => { setLoading(true); await load(); setLoading(false); })();
  }, [load]);

  const onRefresh = async () => { setRefreshing(true); await load(); setRefreshing(false); };

  const prevMonth = () => {
    if (month === 1) { setMonth(12); setYear(y => y - 1); }
    else setMonth(m => m - 1);
  };
  const nextMonth = () => {
    if (month === 12) { setMonth(1); setYear(y => y + 1); }
    else setMonth(m => m + 1);
  };

  // Summary
  const worked = records.filter(r => r.check_in && r.check_out);
  const leaves  = records.filter(r => r.leave_type);
  const totalH  = worked.reduce((s, r) =>
    s + Math.max((new Date(r.check_out) - new Date(r.check_in)) / 3600000, 0), 0);

  const renderItem = ({ item }) => {
    const d   = new Date(item.date);
    const dow = d.toLocaleDateString('en-IN', { weekday: 'short' });
    const dayNum = d.getDate();
    let type = 'absent', timeStr = 'No record', dur = '';

    if (item.leave_type) {
      type = 'leave'; timeStr = item.leave_type;
    } else if (item.check_in && item.check_out) {
      type = 'present';
      const ci  = new Date(item.check_in);
      const co  = new Date(item.check_out);
      const inT = ci.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false });
      const outT= co.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false });
      timeStr = `${inT} → ${outT}`;
      dur = hoursToHHMM(Math.max((co - ci) / 3600000, 0));
    } else if (item.check_in) {
      type = 'present';
      const ci = new Date(item.check_in);
      timeStr = ci.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', hour12: false }) + ' → Active';
    }

    const dotColor = type === 'present' ? colors.emerald : type === 'leave' ? colors.amber : colors.dim;

    return (
      <View style={s.item}>
        <View style={[s.dayDot, { backgroundColor: dotColor + '22' }]}>
          <Text style={[s.dayNum, { color: dotColor }]}>{dayNum}</Text>
          <Text style={[s.dayName, { color: dotColor }]}>{dow}</Text>
        </View>
        <View style={s.itemInfo}>
          <Text style={s.itemDate}>{d.toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}</Text>
          <Text style={s.itemTimes}>{timeStr}</Text>
        </View>
        {dur ? <Text style={s.itemDur}>{dur}</Text> : null}
      </View>
    );
  };

  return (
    <View style={s.root}>
      {/* Month nav */}
      <View style={s.monthNav}>
        <TouchableOpacity style={s.navBtn} onPress={prevMonth}>
          <Text style={s.navBtnText}>‹</Text>
        </TouchableOpacity>
        <Text style={s.monthLabel}>{MONTHS[month - 1]} {year}</Text>
        <TouchableOpacity style={s.navBtn} onPress={nextMonth}>
          <Text style={s.navBtnText}>›</Text>
        </TouchableOpacity>
      </View>

      {/* Summary cards */}
      <View style={s.summaryRow}>
        {[
          { label: 'Present', val: worked.length, color: colors.emerald },
          { label: 'Leaves',  val: leaves.length, color: colors.amber },
          { label: 'Hours',   val: hoursToHHMM(totalH), color: colors.cyan },
        ].map(({ label, val, color }) => (
          <View key={label} style={s.summCard}>
            <Text style={[s.summVal, { color }]}>{val}</Text>
            <Text style={s.summLbl}>{label}</Text>
          </View>
        ))}
      </View>

      {loading ? (
        <ActivityIndicator color={colors.cyan} style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={records}
          keyExtractor={i => i.id?.toString() || i.date}
          renderItem={renderItem}
          contentContainerStyle={s.list}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={colors.cyan} />}
          ListEmptyComponent={
            <View style={s.empty}>
              <Text style={s.emptyIcon}>📅</Text>
              <Text style={s.emptyText}>No records for {MONTHS[month-1]} {year}</Text>
            </View>
          }
          ItemSeparatorComponent={() => <View style={s.sep} />}
        />
      )}
    </View>
  );
}

const s = StyleSheet.create({
  root:       { flex: 1, backgroundColor: colors.bg },
  monthNav:   { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 16, gap: 20, borderBottomWidth: 1, borderColor: colors.border },
  navBtn:     { width: 34, height: 34, borderRadius: 10, backgroundColor: 'rgba(255,255,255,0.06)', alignItems: 'center', justifyContent: 'center' },
  navBtnText: { color: colors.text, fontSize: 20, lineHeight: 22 },
  monthLabel: { fontSize: 17, fontWeight: '700', color: colors.text, minWidth: 120, textAlign: 'center' },

  summaryRow: { flexDirection: 'row', padding: 12, gap: 10 },
  summCard:   { flex: 1, backgroundColor: colors.card, borderWidth: 1, borderColor: colors.border, borderRadius: radius.md, padding: 12, alignItems: 'center' },
  summVal:    { fontSize: 22, fontWeight: '800', fontVariant: ['tabular-nums'] },
  summLbl:    { fontSize: 10, color: colors.muted, textTransform: 'uppercase', letterSpacing: 0.5, marginTop: 2 },

  list:       { padding: 12, paddingBottom: 30 },
  item:       { flexDirection: 'row', alignItems: 'center', gap: 12, paddingVertical: 6 },
  dayDot:     { width: 44, height: 44, borderRadius: 10, alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  dayNum:     { fontSize: 15, fontWeight: '800' },
  dayName:    { fontSize: 9, fontWeight: '600', marginTop: 1 },
  itemInfo:   { flex: 1 },
  itemDate:   { fontSize: 13, fontWeight: '600', color: colors.text },
  itemTimes:  { fontSize: 11, color: colors.muted, marginTop: 2 },
  itemDur:    { fontSize: 14, fontWeight: '700', color: colors.cyan, fontVariant: ['tabular-nums'] },
  sep:        { height: 1, backgroundColor: 'rgba(255,255,255,0.03)', marginLeft: 56 },

  empty:      { alignItems: 'center', paddingTop: 60 },
  emptyIcon:  { fontSize: 40, marginBottom: 12 },
  emptyText:  { color: colors.muted, fontSize: 15 },
});
