import AsyncStorage from '@react-native-async-storage/async-storage';
import axios from 'axios';

const getBaseUrl = async () => await AsyncStorage.getItem('serverUrl') || '';
const getToken   = async () => await AsyncStorage.getItem('accessToken');

const api = axios.create({ timeout: 15000 });

api.interceptors.request.use(async (config) => {
  config.baseURL = await getBaseUrl();
  const token = await getToken();
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

api.interceptors.response.use(
  (res) => res,
  async (error) => {
    const original = error.config;
    if (error.response?.status === 401 && !original._retry) {
      original._retry = true;
      try {
        const refresh  = await AsyncStorage.getItem('refreshToken');
        const baseUrl  = await getBaseUrl();
        const res      = await axios.post(`${baseUrl}/api/token/refresh/`, { refresh });
        await AsyncStorage.setItem('accessToken', res.data.access);
        original.headers.Authorization = `Bearer ${res.data.access}`;
        return api(original);
      } catch {
        await AsyncStorage.multiRemove(['accessToken', 'refreshToken', 'user']);
        throw error;
      }
    }
    throw error;
  }
);

// ── Auth ──────────────────────────────────────────────────────
export const login = async (serverUrl, username, password) => {
  const res = await axios.post(`${serverUrl.replace(/\/$/,'')}/api/token/`, { username, password });
  await AsyncStorage.setItem('serverUrl',     serverUrl.replace(/\/$/,''));
  await AsyncStorage.setItem('accessToken',   res.data.access);
  await AsyncStorage.setItem('refreshToken',  res.data.refresh);
  await AsyncStorage.setItem('user',          username);
  return res.data;
};

export const logout = async () => {
  await AsyncStorage.multiRemove(['accessToken', 'refreshToken', 'user', 'serverUrl']);
};

export const getStoredUser   = () => AsyncStorage.getItem('user');
export const getStoredServer = () => AsyncStorage.getItem('serverUrl');

// ── Attendance ────────────────────────────────────────────────
export const getTodayRecord = async () => {
  const today = formatDate(new Date());
  const res   = await api.get(`/api/v1/attendance/?date=${today}`);
  const list  = res.data.results || res.data;
  return Array.isArray(list) ? list.find(r => r.date === today) || null : null;
};

export const checkIn = async (recordId = null) => {
  const now   = new Date().toISOString();
  const today = formatDate(new Date());
  if (recordId) {
    const res = await api.patch(`/api/v1/attendance/${recordId}/`, { check_in: now });
    return res.data;
  }
  const res = await api.post('/api/v1/attendance/', { date: today, check_in: now });
  return res.data;
};

export const checkOut = async (recordId) => {
  const res = await api.patch(`/api/v1/attendance/${recordId}/`, { check_out: new Date().toISOString() });
  return res.data;
};

export const setManualTime = async (recordId, checkIn, checkOut, date) => {
  const d   = date || formatDate(new Date());
  const payload = {};
  if (checkIn)  payload.check_in  = new Date(`${d}T${checkIn}:00`).toISOString();
  if (checkOut) payload.check_out = new Date(`${d}T${checkOut}:00`).toISOString();
  if (recordId) {
    const res = await api.patch(`/api/v1/attendance/${recordId}/`, payload);
    return res.data;
  }
  payload.date = d;
  const res = await api.post('/api/v1/attendance/', payload);
  return res.data;
};

export const getMonthRecords = async (year, month) => {
  const m   = String(month).padStart(2, '0');
  const res = await api.get(`/api/v1/attendance/?date__gte=${year}-${m}-01&ordering=-date&limit=31`);
  return res.data.results || res.data || [];
};

export const getWeekRecords = async () => {
  const today = new Date();
  const diff  = today.getDay() === 0 ? -6 : 1 - today.getDay();
  const start = new Date(today);
  start.setDate(today.getDate() + diff);
  const res = await api.get(
    `/api/v1/attendance/?date__gte=${formatDate(start)}&date__lte=${formatDate(today)}`
  );
  return res.data.results || res.data || [];
};

export const getProfile = async () => {
  const res = await api.get('/api/v1/profile/');
  return res.data;
};

// ── Helpers ───────────────────────────────────────────────────
export const formatDate = (d) =>
  `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;

export const secToHHMM = (secs) => {
  const s = Math.max(Math.round(secs), 0);
  return `${String(Math.floor(s/3600)).padStart(2,'0')}:${String(Math.floor((s%3600)/60)).padStart(2,'0')}`;
};

export const hoursToHHMM = (h) => secToHHMM(Math.round(h * 3600));

export const calcEarnings = (records, config) => {
  let weekdays = 0, saturdays = 0, lop = 0;
  records.forEach(r => {
    const dow = new Date(r.date).getDay();
    if (r.is_holiday) return;
    if (r.leave_type === 'Loss of Pay') { lop++; return; }
    if (r.leave_type) return;
    if (r.check_in) {
      if (dow >= 1 && dow <= 5) weekdays++;
      else if (dow === 6) saturdays++;
    }
  });
  const wEarn  = weekdays  * (config.dailyRate  || 250);
  const sEarn  = config.satMode === 'pay' ? saturdays * (config.satRate || 250) : 0;
  const lopDed = lop * (config.dailyRate || 250);
  return { weekdays, saturdays, lop, wEarn, sEarn, lopDed, total: wEarn + sEarn - lopDed };
};

export default api;
