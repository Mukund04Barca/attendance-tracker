export const colors = {
  bg:         '#020617',
  surface:    '#0f172a',
  card:       '#0f172a',
  border:     'rgba(255,255,255,0.08)',
  borderHi:   'rgba(0,245,255,0.25)',
  cyan:       '#06b6d4',
  emerald:    '#10b981',
  amber:      '#f59e0b',
  danger:     '#f43f5e',
  purple:     '#a78bfa',
  text:       '#f1f5f9',
  muted:      '#94a3b8',
  dim:        '#475569',
};

export const fonts = {
  regular: 'System',
  bold:    'System',
};

export const radius = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
};
